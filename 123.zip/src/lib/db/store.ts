import fs from 'fs';
import path from 'path';
import {
  Workspace,
  AdAccount,
  Pixel,
  NetworkAccount,
  Offer,
  TrackingLink,
  RawInboundEvent,
  CanonicalConversion,
  OutboxTask,
  DeliveryAttempt,
  IntegrationHealth,
  AuditLog
} from '../types';

interface DatabaseSchema {
  workspaces: Workspace[];
  adAccounts: AdAccount[];
  pixels: Pixel[];
  networkAccounts: NetworkAccount[];
  offers: Offer[];
  trackingLinks: TrackingLink[];
  rawEventLedger: RawInboundEvent[];
  idempotencyRecords: Record<string, { conversionId: string; createdAt: string; network: string }>;
  conversions: CanonicalConversion[];
  outboxTasks: OutboxTask[];
  deliveryAttempts: DeliveryAttempt[];
  integrationHealth: IntegrationHealth[];
  auditLogs: AuditLog[];
}

const DB_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DB_DIR, 'hub_storage.json');

class TransactionalDatabase {
  private data: DatabaseSchema;
  private isSaving: boolean = false;
  private pendingSave: boolean = false;

  constructor() {
    this.ensureDirectory();
    this.data = this.load();
  }

  private ensureDirectory() {
    if (!fs.existsSync(DB_DIR)) {
      fs.mkdirSync(DB_DIR, { recursive: true });
    }
  }

  private load(): DatabaseSchema {
    if (!fs.existsSync(DB_FILE)) {
      const initial: DatabaseSchema = {
        workspaces: [],
        adAccounts: [],
        pixels: [],
        networkAccounts: [],
        offers: [],
        trackingLinks: [],
        rawEventLedger: [],
        idempotencyRecords: {},
        conversions: [],
        outboxTasks: [],
        deliveryAttempts: [],
        integrationHealth: [],
        auditLogs: [],
      };
      this.saveSync(initial);
      return initial;
    }

    try {
      const raw = fs.readFileSync(DB_FILE, 'utf8');
      return JSON.parse(raw);
    } catch (err) {
      console.error('Failed to parse database file, initializing empty backup:', err);
      return {
        workspaces: [],
        adAccounts: [],
        pixels: [],
        networkAccounts: [],
        offers: [],
        trackingLinks: [],
        rawEventLedger: [],
        idempotencyRecords: {},
        conversions: [],
        outboxTasks: [],
        deliveryAttempts: [],
        integrationHealth: [],
        auditLogs: [],
      };
    }
  }

  private saveSync(data: DatabaseSchema) {
    this.ensureDirectory();
    const tempFile = `${DB_FILE}.tmp.${Date.now()}`;
    fs.writeFileSync(tempFile, JSON.stringify(data, null, 2), 'utf8');
    fs.renameSync(tempFile, DB_FILE);
  }

  private async flush() {
    if (this.isSaving) {
      this.pendingSave = true;
      return;
    }
    this.isSaving = true;
    try {
      this.saveSync(this.data);
    } finally {
      this.isSaving = false;
      if (this.pendingSave) {
        this.pendingSave = false;
        await this.flush();
      }
    }
  }

  // Transaction runner for atomic multi-step changes
  public async transaction<T>(fn: () => T | Promise<T>): Promise<T> {
    const result = await fn();
    await this.flush();
    return result;
  }

  // Workspaces
  public getWorkspaces(): Workspace[] {
    return this.data.workspaces;
  }
  public getWorkspaceById(id: string): Workspace | undefined {
    return this.data.workspaces.find(w => w.id === id);
  }
  public saveWorkspace(workspace: Workspace) {
    const idx = this.data.workspaces.findIndex(w => w.id === workspace.id);
    if (idx >= 0) this.data.workspaces[idx] = workspace;
    else this.data.workspaces.push(workspace);
    this.flush();
  }

  // Ad Accounts & Pixels
  public getAdAccounts(workspaceId?: string): AdAccount[] {
    return workspaceId ? this.data.adAccounts.filter(a => a.workspaceId === workspaceId) : this.data.adAccounts;
  }
  public getPixels(workspaceId?: string): Pixel[] {
    return workspaceId ? this.data.pixels.filter(p => p.workspaceId === workspaceId) : this.data.pixels;
  }
  public getPixelById(pixelId: string, workspaceId?: string): Pixel | undefined {
    return this.data.pixels.find(p => p.pixelId === pixelId && (!workspaceId || p.workspaceId === workspaceId));
  }
  public savePixel(pixel: Pixel) {
    const idx = this.data.pixels.findIndex(p => p.id === pixel.id);
    if (idx >= 0) this.data.pixels[idx] = pixel;
    else this.data.pixels.push(pixel);
    this.flush();
  }
  public saveAdAccount(acc: AdAccount) {
    const idx = this.data.adAccounts.findIndex(a => a.id === acc.id);
    if (idx >= 0) this.data.adAccounts[idx] = acc;
    else this.data.adAccounts.push(acc);
    this.flush();
  }

  // Network Accounts
  public getNetworkAccounts(workspaceId?: string): NetworkAccount[] {
    return workspaceId ? this.data.networkAccounts.filter(n => n.workspaceId === workspaceId) : this.data.networkAccounts;
  }
  public getNetworkAccountByToken(network: string, workspaceId: string, token: string): NetworkAccount | undefined {
    return this.data.networkAccounts.find(
      n => n.network === network && n.workspaceId === workspaceId && n.secretToken === token
    );
  }
  public saveNetworkAccount(acc: NetworkAccount) {
    const idx = this.data.networkAccounts.findIndex(n => n.id === acc.id);
    if (idx >= 0) this.data.networkAccounts[idx] = acc;
    else this.data.networkAccounts.push(acc);
    this.flush();
  }

  // Offers
  public getOffers(workspaceId?: string): Offer[] {
    return workspaceId ? this.data.offers.filter(o => o.workspaceId === workspaceId) : this.data.offers;
  }
  public getOfferById(id: string): Offer | undefined {
    return this.data.offers.find(o => o.id === id);
  }
  public saveOffer(offer: Offer) {
    const idx = this.data.offers.findIndex(o => o.id === offer.id);
    if (idx >= 0) this.data.offers[idx] = offer;
    else this.data.offers.push(offer);
    this.flush();
  }

  // Tracking Links
  public getTrackingLinks(workspaceId?: string): TrackingLink[] {
    return workspaceId ? this.data.trackingLinks.filter(t => t.workspaceId === workspaceId) : this.data.trackingLinks;
  }
  public saveTrackingLink(link: TrackingLink) {
    const idx = this.data.trackingLinks.findIndex(t => t.id === link.id);
    if (idx >= 0) this.data.trackingLinks[idx] = link;
    else this.data.trackingLinks.push(link);
    this.flush();
  }

  // Raw Event Ledger (Immutable Ingestion Log)
  public logRawInboundEvent(event: RawInboundEvent) {
    this.data.rawEventLedger.unshift(event); // Newest first
    if (this.data.rawEventLedger.length > 5000) {
      this.data.rawEventLedger.pop(); // Keep bounded memory
    }
    this.flush();
  }
  public getRawEvents(workspaceId?: string, limit = 100): RawInboundEvent[] {
    const filtered = workspaceId ? this.data.rawEventLedger.filter(e => e.workspaceId === workspaceId) : this.data.rawEventLedger;
    return filtered.slice(0, limit);
  }
  public getRawEventById(id: string): RawInboundEvent | undefined {
    return this.data.rawEventLedger.find(e => e.id === id);
  }

  // Idempotency Record Store
  public checkIdempotency(key: string): { exists: boolean; conversionId?: string } {
    const record = this.data.idempotencyRecords[key];
    if (record) return { exists: true, conversionId: record.conversionId };
    return { exists: false };
  }
  public recordIdempotency(key: string, conversionId: string, network: string) {
    this.data.idempotencyRecords[key] = {
      conversionId,
      createdAt: new Date().toISOString(),
      network,
    };
    this.flush();
  }

  // Canonical Conversions
  public getConversions(workspaceId?: string, limit = 200): CanonicalConversion[] {
    const filtered = workspaceId ? this.data.conversions.filter(c => c.workspaceId === workspaceId) : this.data.conversions;
    return filtered.slice(0, limit);
  }
  public getConversionById(id: string): CanonicalConversion | undefined {
    return this.data.conversions.find(c => c.id === id);
  }
  public saveConversion(conversion: CanonicalConversion) {
    const idx = this.data.conversions.findIndex(c => c.id === conversion.id);
    if (idx >= 0) this.data.conversions[idx] = conversion;
    else this.data.conversions.unshift(conversion);
    this.flush();
  }

  // Outbox Tasks
  public getOutboxTasks(status?: string): OutboxTask[] {
    if (status) return this.data.outboxTasks.filter(t => t.status === status);
    return this.data.outboxTasks;
  }
  public getPendingOutboxTasks(limit = 50): OutboxTask[] {
    const now = new Date().toISOString();
    return this.data.outboxTasks
      .filter(t => (t.status === 'pending' || t.status === 'failed_retryable') && t.nextRetryAt <= now)
      .slice(0, limit);
  }
  public saveOutboxTask(task: OutboxTask) {
    const idx = this.data.outboxTasks.findIndex(t => t.id === task.id);
    if (idx >= 0) this.data.outboxTasks[idx] = task;
    else this.data.outboxTasks.unshift(task);
    this.flush();
  }

  // Delivery Attempts
  public recordDeliveryAttempt(attempt: DeliveryAttempt) {
    this.data.deliveryAttempts.unshift(attempt);
    if (this.data.deliveryAttempts.length > 5000) {
      this.data.deliveryAttempts.pop();
    }
    this.flush();
  }
  public getDeliveryAttemptsForConversion(conversionId: string): DeliveryAttempt[] {
    return this.data.deliveryAttempts.filter(d => d.conversionId === conversionId);
  }
  public getDeliveryAttempts(limit = 100): DeliveryAttempt[] {
    return this.data.deliveryAttempts.slice(0, limit);
  }

  // Integration Health
  public getIntegrationHealth(workspaceId?: string): IntegrationHealth[] {
    return workspaceId ? this.data.integrationHealth.filter(h => h.workspaceId === workspaceId) : this.data.integrationHealth;
  }
  public updateIntegrationHealth(health: IntegrationHealth) {
    const idx = this.data.integrationHealth.findIndex(h => h.id === health.id);
    if (idx >= 0) this.data.integrationHealth[idx] = health;
    else this.data.integrationHealth.push(health);
    this.flush();
  }

  // Audit Logs
  public logAudit(log: AuditLog) {
    this.data.auditLogs.unshift(log);
    this.flush();
  }
  public getAuditLogs(workspaceId?: string, limit = 100): AuditLog[] {
    const filtered = workspaceId ? this.data.auditLogs.filter(a => a.workspaceId === workspaceId) : this.data.auditLogs;
    return filtered.slice(0, limit);
  }
}

// Global Singleton Instance
export const db = new TransactionalDatabase();
