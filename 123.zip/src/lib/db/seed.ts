import { db } from './store';
import { encryptSecret } from '../security/crypto';

export const DEFAULT_WORKSPACE_ID = 'ws-master-01';

export function seedInitialData() {
  const existingWorkspaces = db.getWorkspaces();
  if (existingWorkspaces.length > 0) return;

  console.log('Seeding initial verified configuration...');

  // 1. Master Workspace
  db.saveWorkspace({
    id: DEFAULT_WORKSPACE_ID,
    name: 'TikTok Media Buying Hub (Main)',
    slug: 'main-hub',
    createdAt: new Date().toISOString(),
  });

  // 2. TikTok Ad Account & Pixels
  const adAccountId = 'tt-act-884920';
  db.saveAdAccount({
    id: adAccountId,
    workspaceId: DEFAULT_WORKSPACE_ID,
    platform: 'tiktok',
    accountName: 'TikTok Media Scale US',
    externalAccountId: 'ADV-739281902',
    accessTokenEncrypted: encryptSecret('tt_live_access_token_demo_valid_998127391'),
    status: 'active',
    createdAt: new Date().toISOString(),
  });

  const pixel1Id = 'pix-tt-us-health';
  db.savePixel({
    id: pixel1Id,
    workspaceId: DEFAULT_WORKSPACE_ID,
    adAccountId: adAccountId,
    pixelId: 'CP849201948201',
    name: 'US Nutra / Health Scale Pixel',
    testEventCode: 'TEST84920',
    isDefault: true,
    status: 'active',
    createdAt: new Date().toISOString(),
  });

  const pixel2Id = 'pix-tt-us-vsl';
  db.savePixel({
    id: pixel2Id,
    workspaceId: DEFAULT_WORKSPACE_ID,
    adAccountId: adAccountId,
    pixelId: 'CP720194810293',
    name: 'US High-AOV VSL Pixel',
    testEventCode: 'TEST72019',
    isDefault: false,
    status: 'active',
    createdAt: new Date().toISOString(),
  });

  // 3. Network Accounts for the 4 Networks
  const maxwebAccId = 'net-mw-01';
  db.saveNetworkAccount({
    id: maxwebAccId,
    workspaceId: DEFAULT_WORKSPACE_ID,
    network: 'maxweb',
    accountName: 'MaxWeb Pro Affiliate',
    secretToken: 'mw_sec_token_99182',
    status: 'connected',
    createdAt: new Date().toISOString(),
  });

  const buygoodsAccId = 'net-bg-01';
  db.saveNetworkAccount({
    id: buygoodsAccId,
    workspaceId: DEFAULT_WORKSPACE_ID,
    network: 'buygoods',
    accountName: 'BuyGoods Direct Scale',
    secretToken: 'bg_sec_token_55210',
    status: 'connected',
    createdAt: new Date().toISOString(),
  });

  const digistoreAccId = 'net-ds-01';
  db.saveNetworkAccount({
    id: digistoreAccId,
    workspaceId: DEFAULT_WORKSPACE_ID,
    network: 'digistore24',
    accountName: 'Digistore24 Affiliate EU/US',
    secretToken: 'ds_sec_token_77341',
    webhookSecretEncrypted: encryptSecret('ds_sha512_secret_passphrase_2026'),
    status: 'connected',
    createdAt: new Date().toISOString(),
  });

  const clickbankAccId = 'net-cb-01';
  db.saveNetworkAccount({
    id: clickbankAccId,
    workspaceId: DEFAULT_WORKSPACE_ID,
    network: 'clickbank',
    accountName: 'ClickBank Top Earner',
    secretToken: 'cb_sec_token_11492',
    webhookSecretEncrypted: encryptSecret('CBSECRETKEY2026'),
    status: 'connected',
    createdAt: new Date().toISOString(),
  });

  // 4. Sample Verified Offers
  const offerMaxWeb = 'off-mw-prodentim';
  db.saveOffer({
    id: offerMaxWeb,
    workspaceId: DEFAULT_WORKSPACE_ID,
    networkAccountId: maxwebAccId,
    network: 'maxweb',
    networkOfferId: 'MW-9042',
    name: 'ProDentim Dental Health VSL',
    defaultPayout: 135.0,
    currency: 'USD',
    targetUrl: 'https://maxweb.com/aff/9042/12093',
    defaultPixelId: 'CP849201948201',
    allowedTrafficSources: ['tiktok', 'meta', 'native'],
    geoRestrictions: ['US', 'CA', 'AU', 'UK'],
    createdAt: new Date().toISOString(),
  });

  const offerBuyGoods = 'off-bg-neurodr';
  db.saveOffer({
    id: offerBuyGoods,
    workspaceId: DEFAULT_WORKSPACE_ID,
    networkAccountId: buygoodsAccId,
    network: 'buygoods',
    networkOfferId: 'BG-7102',
    name: 'NeuroDr Brain Clarity',
    defaultPayout: 142.5,
    currency: 'USD',
    targetUrl: 'https://www.buygoods.com/affiliate/redirect.html?aff_id=8831&prod_id=7102',
    defaultPixelId: 'CP849201948201',
    allowedTrafficSources: ['tiktok', 'youtube'],
    geoRestrictions: ['US'],
    createdAt: new Date().toISOString(),
  });

  const offerDigistore = 'off-ds-manifest';
  db.saveOffer({
    id: offerDigistore,
    workspaceId: DEFAULT_WORKSPACE_ID,
    networkAccountId: digistoreAccId,
    network: 'digistore24',
    networkOfferId: 'DS-48190',
    name: 'Quantum Manifestation Code',
    defaultPayout: 47.0,
    currency: 'USD',
    targetUrl: 'https://www.digistore24.com/redir/48190/mediaflow/CAMPAIGN1',
    defaultPixelId: 'CP720194810293',
    allowedTrafficSources: ['tiktok', 'facebook', 'instagram'],
    geoRestrictions: ['US', 'CA', 'NZ', 'AU', 'GB'],
    createdAt: new Date().toISOString(),
  });

  const offerClickbank = 'off-cb-alphatonic';
  db.saveOffer({
    id: offerClickbank,
    workspaceId: DEFAULT_WORKSPACE_ID,
    networkAccountId: clickbankAccId,
    network: 'clickbank',
    networkOfferId: 'CB-ALPHATONIC',
    name: 'Alpha Tonic Male Energy',
    defaultPayout: 154.0,
    currency: 'USD',
    targetUrl: 'https://hop.clickbank.net/?affiliate=topbuyer&vendor=alphatonic',
    defaultPixelId: 'CP849201948201',
    allowedTrafficSources: ['tiktok', 'meta', 'google_search'],
    geoRestrictions: ['US', 'CA'],
    createdAt: new Date().toISOString(),
  });

  // 5. Initial Tracking Links
  db.saveTrackingLink({
    id: 'link-prodentim-tt-us01',
    workspaceId: DEFAULT_WORKSPACE_ID,
    offerId: offerMaxWeb,
    pixelId: 'CP849201948201',
    campaignLabel: 'TT-US-NUTR-01',
    adgroupLabel: 'AG-BROAD-35PLUS',
    adLabel: 'AD-HOOK-2',
    creativeLabel: 'CR-ANIMATION-03',
    clickIdParameter: 'subid',
    generatedDestinationUrl: 'https://maxweb.com/aff/9042/12093?subid=__CLICKID__&subid2=TT-US-NUTR-01&subid3=AG-BROAD-35PLUS&subid4=AD-HOOK-2&subid5=CR-ANIMATION-03',
    createdAt: new Date().toISOString(),
  });

  // 6. Initialize Integration Health for each connected account
  const accounts = [
    { id: maxwebAccId, net: 'maxweb' as const },
    { id: buygoodsAccId, net: 'buygoods' as const },
    { id: digistoreAccId, net: 'digistore24' as const },
    { id: clickbankAccId, net: 'clickbank' as const },
  ];

  for (const acc of accounts) {
    db.updateIntegrationHealth({
      id: `health-${acc.id}`,
      workspaceId: DEFAULT_WORKSPACE_ID,
      networkAccountId: acc.id,
      network: acc.net,
      status: 'healthy',
      totalPostbacksReceived: 0,
      totalConversionsProcessed: 0,
      missingClickIdCount: 0,
      duplicateCount: 0,
      failedDeliveriesCount: 0,
      attributionRate: 100,
      deliveryRate: 100,
      updatedAt: new Date().toISOString(),
    });
  }

  console.log('Seed configuration completed.');
}

// Auto-run seed
seedInitialData();
