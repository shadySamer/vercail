export type CanonicalEventType =
  | 'checkout_started'
  | 'purchase'
  | 'upsell'
  | 'rebill'
  | 'refund'
  | 'chargeback'
  | 'cancelled'
  | 'commission_adjustment'
  | 'unknown';

export type ConversionStatus =
  | 'received'
  | 'validated'
  | 'normalized'
  | 'attributed'
  | 'queued'
  | 'sent'
  | 'accepted'
  | 'unattributed'
  | 'duplicate'
  | 'failed_retryable'
  | 'failed_permanent'
  | 'quarantined';

export type OutboxStatus =
  | 'pending'
  | 'processing'
  | 'delivered'
  | 'failed_retryable'
  | 'failed_permanent';

export type NetworkType = 'maxweb' | 'buygoods' | 'digistore24' | 'clickbank';

export type AdPlatformType = 'tiktok' | 'meta' | 'google';

export type IntegrationHealthStatus = 'healthy' | 'warning' | 'broken' | 'disconnected';

export interface Workspace {
  id: string;
  name: string;
  slug: string;
  createdAt: string;
}

export interface AdAccount {
  id: string;
  workspaceId: string;
  platform: AdPlatformType;
  accountName: string;
  externalAccountId: string;
  accessTokenEncrypted: string;
  tokenExpiresAt?: string;
  status: 'active' | 'expired' | 'revoked';
  createdAt: string;
}

export interface Pixel {
  id: string;
  workspaceId: string;
  adAccountId?: string;
  pixelId: string; // TikTok Pixel / Event Source ID
  name: string;
  accessTokenEncrypted?: string; // Long-lived Events API Access Token
  eventName?: string; // e.g. CompletePayment
  testEventCode?: string; // TikTok test_event_code for debugging
  isDefault?: boolean;
  status: 'active' | 'inactive';
  createdAt: string;
}

export interface NetworkAccount {
  id: string;
  workspaceId: string;
  network: NetworkType;
  accountName: string;
  secretToken: string; // Used in postback URL endpoint
  webhookSecretEncrypted?: string; // Passphrase or secret key
  targetPixelId?: string; // Target TikTok Pixel for this network's conversions
  targetEventName?: string; // Target event name (default: CompletePayment)
  clickIdParamName?: string; // Preferred SubID field (e.g. subid, subid5, cid, extclid)
  status: 'connected' | 'disconnected' | 'error';
  createdAt: string;
}

export interface Offer {
  id: string;
  workspaceId: string;
  networkAccountId: string;
  network: NetworkType;
  networkOfferId: string;
  name: string;
  defaultPayout: number;
  currency: string;
  targetUrl: string;
  defaultPixelId?: string;
  allowedTrafficSources: string[];
  geoRestrictions?: string[];
  createdAt: string;
}

export interface TrackingLink {
  id: string;
  workspaceId: string;
  offerId: string;
  pixelId: string;
  campaignLabel: string;
  adgroupLabel?: string;
  adLabel?: string;
  creativeLabel?: string;
  custom1?: string;
  custom2?: string;
  generatedDestinationUrl: string;
  clickIdParameter: string;
  createdAt: string;
}

export interface RawInboundEvent {
  id: string;
  workspaceId: string;
  network: NetworkType;
  networkAccountId?: string;
  headers: Record<string, string>;
  queryParams: Record<string, string>;
  body: any;
  rawPayload: string;
  clientIp: string;
  verificationStatus: 'verified' | 'unverified' | 'failed_signature' | 'invalid_token';
  processingStatus: 'processed' | 'duplicate' | 'failed' | 'quarantined';
  receivedAt: string;
  errorMessage?: string;
}

export interface CanonicalConversion {
  id: string;
  workspaceId: string;
  rawEventId: string;
  network: NetworkType;
  networkAccountId: string;
  transactionId: string; // Unique network order ID or receipt
  parentTransactionId?: string; // For upsells / rebills
  orderItemId?: string; // Sub-item ID in basket / upsell
  eventType: CanonicalEventType;
  targetEventName?: string; // Mapped event for TikTok (e.g. CompletePayment)
  status: ConversionStatus;

  // Financial fields (Strict separation of Commission vs Gross)
  currency: string;
  commissionAmount: number;
  grossAmount?: number;
  refundedAmount?: number;

  // Deterministic Attribution Evidence
  clickId?: string; // TikTok ttclid
  trafficSource: string;
  campaignId?: string;
  adgroupId?: string;
  adId?: string;
  creativeId?: string;
  offerId?: string;
  offerName?: string;
  productName?: string;

  // Resolved Delivery Destination
  resolvedPixelId?: string;
  resolvedAdAccountId?: string;

  // Customer match keys (if available & hashed)
  customerIp?: string;
  customerUserAgent?: string;
  customerEmailHashed?: string;
  customerPhoneHashed?: string;

  // Integrity & Audit
  idempotencyKey: string;
  receivedAt: string;
  processedAt?: string;
  errorMessage?: string;
}

export interface OutboxTask {
  id: string;
  workspaceId: string;
  conversionId: string;
  adPlatform: AdPlatformType;
  destinationPixelId: string;
  payload: any;
  status: OutboxStatus;
  attempts: number;
  maxAttempts: number;
  nextRetryAt: string;
  lastAttemptAt?: string;
  lastError?: string;
  createdAt: string;
  updatedAt: string;
}

export interface DeliveryAttempt {
  id: string;
  outboxTaskId: string;
  conversionId: string;
  adPlatform: AdPlatformType;
  endpointUrl: string;
  requestHeaders: Record<string, string>;
  requestPayload: any;
  responseStatusCode: number;
  responseBody: any;
  latencyMs: number;
  isSuccess: boolean;
  errorClassification?: 'RETRYABLE' | 'PERMANENT';
  errorMessage?: string;
  attemptedAt: string;
}

export interface IntegrationHealth {
  id: string;
  workspaceId: string;
  networkAccountId: string;
  network: NetworkType;
  status: IntegrationHealthStatus;
  lastPostbackAt?: string;
  lastConversionAt?: string;
  lastTikTokDeliveryAt?: string;
  totalPostbacksReceived: number;
  totalConversionsProcessed: number;
  missingClickIdCount: number;
  duplicateCount: number;
  failedDeliveriesCount: number;
  attributionRate: number; // Percentage
  deliveryRate: number; // Percentage
  updatedAt: string;
}

export interface AuditLog {
  id: string;
  workspaceId: string;
  entityType: 'pixel' | 'token' | 'network_account' | 'tracking_rule' | 'offer';
  entityId: string;
  action: 'create' | 'update' | 'delete' | 'rotate_token';
  actor: string;
  previousValue?: any;
  newValue?: any;
  timestamp: string;
}

export interface NormalizedNetworkResult {
  isVerified: boolean;
  verificationError?: string;
  transactionId: string;
  parentTransactionId?: string;
  orderItemId?: string;
  eventType: CanonicalEventType;
  currency: string;
  commissionAmount: number;
  grossAmount?: number;
  clickId?: string;
  offerIdentifier?: string;
  productName?: string;
  campaignLabel?: string;
  adgroupLabel?: string;
  adLabel?: string;
  creativeLabel?: string;
  customerIp?: string;
  customerUserAgent?: string;
  customerEmail?: string;
  customerPhone?: string;
  rawDetails?: Record<string, any>;
}

export interface VerificationCapabilityMatrix {
  network: NetworkType;
  directLinking: 'VERIFIED' | 'UNSUPPORTED' | 'UNKNOWN';
  clickIdPersistence: 'VERIFIED' | 'UNSUPPORTED' | 'UNKNOWN';
  s2sPostback: 'VERIFIED' | 'UNSUPPORTED' | 'UNKNOWN';
  purchaseEvent: 'VERIFIED' | 'UNSUPPORTED' | 'UNKNOWN';
  upsellEvent: 'VERIFIED' | 'UNSUPPORTED' | 'UNKNOWN';
  rebillEvent: 'VERIFIED' | 'UNSUPPORTED' | 'UNKNOWN';
  refundEvent: 'VERIFIED' | 'UNSUPPORTED' | 'UNKNOWN';
  chargebackEvent: 'VERIFIED' | 'UNSUPPORTED' | 'UNKNOWN';
  commissionPayout: 'VERIFIED' | 'UNSUPPORTED' | 'UNKNOWN';
  grossRevenue: 'VERIFIED' | 'UNSUPPORTED' | 'UNKNOWN';
  signedSecurity: 'VERIFIED' | 'UNSUPPORTED' | 'UNKNOWN';
  testSimulation: 'VERIFIED' | 'UNSUPPORTED' | 'UNKNOWN';
  notes: string;
}
