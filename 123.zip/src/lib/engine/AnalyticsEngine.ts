import { db } from '../db/store';
import { CanonicalConversion } from '../types';

export interface CampaignFinancials {
  campaignName: string;
  network: string;
  offerName: string;
  adSpend: number;
  conversionsCount: number;
  initialSalesCount: number;
  upsellsCount: number;
  refundsCount: number;
  grossCommission: number;
  refundedCommission: number;
  netCommission: number;
  netProfit: number;
  roas: number;
  cpa: number;
  status: 'profitable' | 'break_even' | 'unprofitable';
}

export interface DashboardSummary {
  adSpend: number;
  grossCommission: number;
  refundedCommission: number;
  netCommission: number;
  netProfit: number;
  roas: number;
  cpa: number;
  totalConversions: number;
  attributedConversions: number;
  unattributedConversions: number;
  acceptedDeliveries: number;
  attributionRate: number;
  deliveryRate: number;
  campaigns: CampaignFinancials[];
}

export class AnalyticsEngine {
  /**
   * Aggregate true media buyer financials and attribution metrics
   */
  public getDashboardMetrics(workspaceId: string): DashboardSummary {
    const conversions = db.getConversions(workspaceId);

    // Mock/Integrated Ad spend benchmark per campaign for demo/real media buying view
    const campaignSpendMap: Record<string, number> = {
      'TT-US-NUTR-01': 1420.0,
      'TT-US-VSL-SCALE': 890.0,
      'TT-GLOBAL-DIGI': 450.0,
      'TT-CB-ALPHA': 620.0,
      'DEFAULT': 200.0,
    };

    let grossCommission = 0;
    let refundedCommission = 0;
    let totalConversions = 0;
    let attributedConversions = 0;
    let unattributedConversions = 0;
    let acceptedDeliveries = 0;

    const campaignStats: Record<string, {
      network: string;
      offerName: string;
      conversions: number;
      initialSales: number;
      upsells: number;
      refunds: number;
      commission: number;
      refunded: number;
    }> = {};

    for (const c of conversions) {
      totalConversions++;
      const campaignKey = c.campaignId || 'Unattributed Traffic';

      if (!campaignStats[campaignKey]) {
        campaignStats[campaignKey] = {
          network: c.network,
          offerName: c.offerName || c.productName || 'Direct Offer',
          conversions: 0,
          initialSales: 0,
          upsells: 0,
          refunds: 0,
          commission: 0,
          refunded: 0,
        };
      }

      if (c.status === 'unattributed') {
        unattributedConversions++;
      } else {
        attributedConversions++;
      }

      if (c.status === 'accepted') {
        acceptedDeliveries++;
      }

      if (c.eventType === 'refund' || c.eventType === 'chargeback') {
        refundedCommission += c.commissionAmount;
        campaignStats[campaignKey].refunds += 1;
        campaignStats[campaignKey].refunded += c.commissionAmount;
      } else if (c.eventType === 'upsell') {
        grossCommission += c.commissionAmount;
        campaignStats[campaignKey].conversions += 1;
        campaignStats[campaignKey].upsells += 1;
        campaignStats[campaignKey].commission += c.commissionAmount;
      } else {
        grossCommission += c.commissionAmount;
        campaignStats[campaignKey].conversions += 1;
        campaignStats[campaignKey].initialSales += 1;
        campaignStats[campaignKey].commission += c.commissionAmount;
      }
    }

    const netCommission = Math.max(0, grossCommission - refundedCommission);

    // Compute total ad spend across campaigns
    let totalAdSpend = 0;
    const campaigns: CampaignFinancials[] = Object.keys(campaignStats).map(name => {
      const stat = campaignStats[name];
      const spend = campaignSpendMap[name] || (stat.conversions * 45); // estimated spend if not explicitly mapped
      totalAdSpend += spend;

      const netComm = Math.max(0, stat.commission - stat.refunded);
      const profit = netComm - spend;
      const roas = spend > 0 ? Number((netComm / spend).toFixed(2)) : 0;
      const cpa = stat.conversions > 0 ? Number((spend / stat.conversions).toFixed(2)) : 0;

      return {
        campaignName: name,
        network: stat.network,
        offerName: stat.offerName,
        adSpend: spend,
        conversionsCount: stat.conversions,
        initialSalesCount: stat.initialSales,
        upsellsCount: stat.upsells,
        refundsCount: stat.refunds,
        grossCommission: stat.commission,
        refundedCommission: stat.refunded,
        netCommission: netComm,
        netProfit: profit,
        roas,
        cpa,
        status: profit > 0 ? 'profitable' : profit === 0 ? 'break_even' : 'unprofitable',
      };
    });

    if (campaigns.length === 0) {
      // Baseline view if fresh
      totalAdSpend = 0;
    }

    const netProfit = netCommission - totalAdSpend;
    const overallRoas = totalAdSpend > 0 ? Number((netCommission / totalAdSpend).toFixed(2)) : 0;
    const overallCpa = totalConversions > 0 ? Number((totalAdSpend / totalConversions).toFixed(2)) : 0;
    const attributionRate = totalConversions > 0 ? Math.round((attributedConversions / totalConversions) * 100) : 100;
    const deliveryRate = totalConversions > 0 ? Math.round((acceptedDeliveries / (totalConversions - unattributedConversions || 1)) * 100) : 100;

    return {
      adSpend: totalAdSpend,
      grossCommission,
      refundedCommission,
      netCommission,
      netProfit,
      roas: overallRoas,
      cpa: overallCpa,
      totalConversions,
      attributedConversions,
      unattributedConversions,
      acceptedDeliveries,
      attributionRate,
      deliveryRate: Math.min(100, deliveryRate),
      campaigns,
    };
  }
}

export const analyticsEngine = new AnalyticsEngine();
