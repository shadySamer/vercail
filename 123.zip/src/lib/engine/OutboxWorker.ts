import { v4 as uuidv4 } from 'uuid';
import { db } from '../db/store';
import { tikTokAdsAdapter } from '../adapters/ad-platform/TikTokAdsAdapter';
import { decryptSecret } from '../security/crypto';
import { OutboxTask, DeliveryAttempt, IntegrationHealth } from '../types';

export class OutboxWorker {
  private isProcessing = false;

  /**
   * Process all pending or retryable outbox tasks
   */
  public async processPending(limit = 20): Promise<{ processed: number; succeeded: number; failed: number }> {
    if (this.isProcessing) return { processed: 0, succeeded: 0, failed: 0 };
    this.isProcessing = true;

    let processed = 0;
    let succeeded = 0;
    let failed = 0;

    try {
      const tasks = db.getPendingOutboxTasks(limit);
      for (const task of tasks) {
        const result = await this.processTask(task);
        processed++;
        if (result.success) succeeded++;
        else failed++;
      }
    } finally {
      this.isProcessing = false;
    }

    return { processed, succeeded, failed };
  }

  /**
   * Process a single Outbox Task with durability and audit trail
   */
  public async processTask(task: OutboxTask): Promise<{ success: boolean; error?: string }> {
    const conversion = db.getConversionById(task.conversionId);
    if (!conversion) {
      task.status = 'failed_permanent';
      task.lastError = 'Referenced Conversion not found';
      db.saveOutboxTask(task);
      return { success: false, error: 'Conversion missing' };
    }

    // Resolve Destination Pixel
    const pixel = db.getPixelById(task.destinationPixelId, task.workspaceId);
    if (!pixel) {
      task.status = 'failed_permanent';
      task.lastError = `Target Pixel ${task.destinationPixelId} not found in workspace`;
      conversion.status = 'failed_permanent';
      conversion.errorMessage = task.lastError;
      db.saveOutboxTask(task);
      db.saveConversion(conversion);
      return { success: false, error: task.lastError };
    }

    // Resolve Decrypted Access Token directly from Pixel or linked Ad Account
    let accessToken = 'mock_demo_token';
    if (pixel.accessTokenEncrypted) {
      accessToken = decryptSecret(pixel.accessTokenEncrypted);
    } else {
      const adAccount = db.getAdAccounts(task.workspaceId).find(a => a.id === pixel.adAccountId);
      if (adAccount?.accessTokenEncrypted) {
        accessToken = decryptSecret(adAccount.accessTokenEncrypted);
      }
    }

    // Dispatch to Ad Platform (TikTok)
    const dispatchResult = await tikTokAdsAdapter.dispatchConversion(
      conversion,
      pixel,
      accessToken,
      { testEventCode: pixel.testEventCode }
    );

    // Record Delivery Attempt Audit Trail
    const attempt: DeliveryAttempt = {
      id: uuidv4(),
      outboxTaskId: task.id,
      conversionId: conversion.id,
      adPlatform: task.adPlatform,
      endpointUrl: 'https://business-api.tiktok.com/open_api/v1.3/event/track/',
      requestHeaders: {
        'Access-Token': '••••••••••••',
        'Content-Type': 'application/json',
      },
      requestPayload: {
        event_source_id: pixel.pixelId,
        event: 'CompletePayment',
        event_id: conversion.orderItemId || conversion.transactionId,
        click_id: conversion.clickId,
        value: conversion.commissionAmount,
        currency: conversion.currency,
      },
      responseStatusCode: dispatchResult.statusCode,
      responseBody: dispatchResult.responseBody,
      latencyMs: dispatchResult.latencyMs,
      isSuccess: dispatchResult.isSuccess,
      errorClassification: dispatchResult.errorClassification,
      errorMessage: dispatchResult.errorMessage,
      attemptedAt: new Date().toISOString(),
    };
    db.recordDeliveryAttempt(attempt);

    // Update Task & Conversion State
    task.attempts += 1;
    task.lastAttemptAt = attempt.attemptedAt;
    task.updatedAt = attempt.attemptedAt;

    if (dispatchResult.isSuccess) {
      task.status = 'delivered';
      task.lastError = undefined;
      conversion.status = 'accepted';
      conversion.processedAt = attempt.attemptedAt;
      conversion.errorMessage = undefined;

      this.updateHealthSuccess(task.workspaceId, conversion.networkAccountId);
      db.saveOutboxTask(task);
      db.saveConversion(conversion);
      return { success: true };
    }

    // Failure Handling
    task.lastError = dispatchResult.errorMessage || `HTTP ${dispatchResult.statusCode}`;
    conversion.errorMessage = task.lastError;

    if (dispatchResult.errorClassification === 'PERMANENT' || task.attempts >= task.maxAttempts) {
      task.status = 'failed_permanent';
      conversion.status = 'failed_permanent';
      this.updateHealthFailure(task.workspaceId, conversion.networkAccountId, true);
    } else {
      // Exponential Backoff: (2 ^ attempts) * 10 seconds
      const backoffSec = Math.pow(2, task.attempts) * 10;
      task.nextRetryAt = new Date(Date.now() + backoffSec * 1000).toISOString();
      task.status = 'failed_retryable';
      conversion.status = 'failed_retryable';
      this.updateHealthFailure(task.workspaceId, conversion.networkAccountId, false);
    }

    db.saveOutboxTask(task);
    db.saveConversion(conversion);
    return { success: false, error: task.lastError };
  }

  private updateHealthSuccess(workspaceId: string, networkAccountId: string) {
    const healthList = db.getIntegrationHealth(workspaceId);
    let health = healthList.find(h => h.networkAccountId === networkAccountId);
    if (health) {
      health.lastTikTokDeliveryAt = new Date().toISOString();
      health.totalConversionsProcessed += 1;
      const total = health.totalConversionsProcessed;
      const failed = health.failedDeliveriesCount;
      health.deliveryRate = total > 0 ? Math.round(((total - failed) / total) * 100) : 100;
      health.status = health.deliveryRate >= 95 ? 'healthy' : 'warning';
      health.updatedAt = new Date().toISOString();
      db.updateIntegrationHealth(health);
    }
  }

  private updateHealthFailure(workspaceId: string, networkAccountId: string, isPermanent: boolean) {
    const healthList = db.getIntegrationHealth(workspaceId);
    let health = healthList.find(h => h.networkAccountId === networkAccountId);
    if (health) {
      if (isPermanent) health.failedDeliveriesCount += 1;
      const total = health.totalConversionsProcessed + (isPermanent ? 1 : 0);
      const failed = health.failedDeliveriesCount;
      health.deliveryRate = total > 0 ? Math.max(0, Math.round(((total - failed) / total) * 100)) : 100;
      health.status = health.deliveryRate < 80 ? 'broken' : 'warning';
      health.updatedAt = new Date().toISOString();
      db.updateIntegrationHealth(health);
    }
  }
}

export const outboxWorker = new OutboxWorker();
