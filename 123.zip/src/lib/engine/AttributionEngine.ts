import { db } from '../db/store';
import { NormalizedNetworkResult, NetworkAccount, Pixel } from '../types';

export interface AttributionResult {
  status: 'attributed' | 'unattributed';
  resolvedPixel?: Pixel;
  resolvedAdAccountId?: string;
  targetEventName: string;
  offerId?: string;
  offerName?: string;
  campaignId?: string;
  adgroupId?: string;
  adId?: string;
  creativeId?: string;
  reason?: string;
}

export class AttributionEngine {
  /**
   * Deterministically attributes an inbound normalized transaction to a TikTok Pixel and Campaign
   */
  public attribute(
    normalized: NormalizedNetworkResult,
    networkAccount: NetworkAccount,
    workspaceId: string
  ): AttributionResult {
    const defaultEventName = networkAccount.targetEventName || 'CompletePayment';

    // Check 1: Deterministic Click ID Evidence
    if (!normalized.clickId || normalized.clickId.trim() === '') {
      return {
        status: 'unattributed',
        targetEventName: defaultEventName,
        reason: 'Missing or unreplaced TikTok Click ID (ttclid)',
      };
    }

    // Check 2: Match directly via Network Account assigned Pixel
    const pixels = db.getPixels(workspaceId).filter(p => p.status === 'active');
    let targetPixel: Pixel | undefined;

    if (networkAccount.targetPixelId) {
      targetPixel = pixels.find(p => p.pixelId === networkAccount.targetPixelId);
    }

    // Check 3: Match via Tracking Links / Campaigns if present
    if (!targetPixel && normalized.campaignLabel) {
      const trackingLinks = db.getTrackingLinks(workspaceId);
      const matchedLink = trackingLinks.find(
        l => l.campaignLabel.toLowerCase() === normalized.campaignLabel?.toLowerCase()
      );
      if (matchedLink) {
        targetPixel = pixels.find(p => p.pixelId === matchedLink.pixelId);
      }
    }

    // Check 4: Fallback to workspace default Pixel
    if (!targetPixel) {
      targetPixel = pixels.find(p => p.isDefault) || pixels[0];
    }

    if (!targetPixel) {
      return {
        status: 'unattributed',
        targetEventName: defaultEventName,
        reason: 'No active TikTok Pixel found in workspace. Please configure a Pixel ID in settings.',
      };
    }

    const eventName = targetPixel.eventName || networkAccount.targetEventName || 'CompletePayment';

    return {
      status: 'attributed',
      resolvedPixel: targetPixel,
      resolvedAdAccountId: targetPixel.adAccountId,
      targetEventName: eventName,
      offerName: normalized.productName,
      campaignId: normalized.campaignLabel,
      adgroupId: normalized.adgroupLabel,
      adId: normalized.adLabel,
      creativeId: normalized.creativeLabel,
    };
  }
}

export const attributionEngine = new AttributionEngine();
