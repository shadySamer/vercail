import crypto from 'crypto';
import { db } from '../db/store';
import { NetworkType, CanonicalEventType } from '../types';

export class IdempotencyEngine {
  /**
   * Generates a deterministic SHA-256 idempotency hash for an incoming transaction
   */
  public generateKey(
    network: NetworkType,
    networkAccountId: string,
    transactionId: string,
    eventType: CanonicalEventType,
    orderItemId?: string
  ): string {
    const rawIdentity = [
      network.toLowerCase(),
      networkAccountId,
      transactionId.trim(),
      eventType.toLowerCase(),
      (orderItemId || '').trim(),
    ].join(':');

    return crypto.createHash('sha256').update(rawIdentity).digest('hex');
  }

  /**
   * Check if this transaction has already been recorded
   */
  public check(idempotencyKey: string): { isDuplicate: boolean; existingConversionId?: string } {
    const check = db.checkIdempotency(idempotencyKey);
    return {
      isDuplicate: check.exists,
      existingConversionId: check.conversionId,
    };
  }

  /**
   * Commit the idempotency record atomically
   */
  public record(idempotencyKey: string, conversionId: string, network: NetworkType) {
    db.recordIdempotency(idempotencyKey, conversionId, network);
  }
}

export const idempotencyEngine = new IdempotencyEngine();
