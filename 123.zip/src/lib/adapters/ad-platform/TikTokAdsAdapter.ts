import { AdPlatformAdapter, DispatchResult } from './AdPlatformAdapter';
import { CanonicalConversion, Pixel } from '../../types';

export class TikTokAdsAdapter implements AdPlatformAdapter {
  public platform = 'tiktok' as const;
  private apiEndpoint = 'https://business-api.tiktok.com/open_api/v1.3/event/track/';

  public classifyError(statusCode: number, responseBody: any): 'RETRYABLE' | 'PERMANENT' {
    if (statusCode === 429 || statusCode >= 500) {
      return 'RETRYABLE';
    }

    const code = responseBody?.code;
    const message = (responseBody?.message || '').toLowerCase();

    if (code === 40001 || message.includes('permission') || message.includes('token') || statusCode === 401) {
      return 'PERMANENT';
    }
    if (code === 40002 || message.includes('pixel') || message.includes('parameter') || statusCode === 400) {
      return 'PERMANENT';
    }

    return 'RETRYABLE';
  }

  public async dispatchConversion(
    conversion: CanonicalConversion,
    pixel: Pixel,
    accessToken: string,
    options: { testEventCode?: string; isSimulation?: boolean } = {}
  ): Promise<DispatchResult> {
    const startTime = Date.now();

    // Deduplication Key: Use order item ID (for upsells) or top-level transaction ID
    const eventId = conversion.orderItemId || conversion.transactionId;

    // Unix timestamp in seconds
    const eventTime = Math.floor(new Date(conversion.receivedAt || Date.now()).getTime() / 1000);

    // Event name mapping (e.g. CompletePayment, Purchase)
    const eventName = conversion.targetEventName || pixel.eventName || 'CompletePayment';

    // Prepare User matching block
    const userPayload: Record<string, any> = {};
    if (conversion.clickId) {
      userPayload.ttclid = conversion.clickId;
    }
    if (conversion.customerIp) {
      userPayload.ip = conversion.customerIp;
    }
    if (conversion.customerUserAgent) {
      userPayload.user_agent = conversion.customerUserAgent;
    }
    if (conversion.customerEmailHashed) {
      userPayload.email = conversion.customerEmailHashed;
    }
    if (conversion.customerPhoneHashed) {
      userPayload.phone = conversion.customerPhoneHashed;
    }

    // Determine event value
    const eventValue = conversion.commissionAmount > 0 ? conversion.commissionAmount : (conversion.grossAmount || 0);

    // Build the standardized TikTok Web Events payload
    const payload: Record<string, any> = {
      event_source: 'web',
      event_source_id: pixel.pixelId,
      data: [
        {
          event: eventName,
          event_time: eventTime,
          event_id: eventId,
          user: userPayload,
          properties: {
            currency: conversion.currency || 'USD',
            value: Number(eventValue.toFixed(2)),
            contents: [
              {
                content_id: conversion.productName || conversion.offerName || 'AFFILIATE-OFFER',
                content_type: 'product',
                quantity: 1,
                price: Number(eventValue.toFixed(2)),
              },
            ],
          },
        },
      ],
    };

    // Test Event Code for Sandbox validation
    const testCode = options.testEventCode || pixel.testEventCode;
    if (testCode) {
      payload.test_event_code = testCode;
    }

    // In simulation mode or demo token
    if (options.isSimulation || accessToken.includes('demo') || accessToken.includes('mock')) {
      const latencyMs = Math.max(15, Date.now() - startTime + Math.floor(Math.random() * 60 + 30));
      return {
        isSuccess: true,
        statusCode: 200,
        responseBody: {
          code: 0,
          message: 'OK',
          data: {
            pixel_id: pixel.pixelId,
            event: eventName,
            event_id: eventId,
            events_processed: 1,
            test_mode: !!testCode,
          },
          log_id: `mock_tt_log_${Date.now()}`,
        },
        latencyMs,
      };
    }

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10000);

      const response = await fetch(this.apiEndpoint, {
        method: 'POST',
        headers: {
          'Access-Token': accessToken,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);
      const latencyMs = Date.now() - startTime;

      let responseBody: any = {};
      try {
        responseBody = await response.json();
      } catch {
        responseBody = { rawText: await response.text() };
      }

      const isSuccess = response.ok && (responseBody.code === 0 || responseBody.code === 'OK');
      const classification = isSuccess ? undefined : this.classifyError(response.status, responseBody);

      return {
        isSuccess,
        statusCode: response.status,
        responseBody,
        latencyMs,
        errorClassification: classification,
        errorMessage: isSuccess ? undefined : responseBody.message || `HTTP ${response.status}`,
      };
    } catch (err: any) {
      const latencyMs = Date.now() - startTime;
      const isTimeout = err.name === 'AbortError' || err.message?.includes('timeout');
      return {
        isSuccess: false,
        statusCode: isTimeout ? 408 : 500,
        responseBody: { error: err.message, isTimeout },
        latencyMs,
        errorClassification: 'RETRYABLE',
        errorMessage: `Network transport failure: ${err.message}`,
      };
    }
  }
}

export const tikTokAdsAdapter = new TikTokAdsAdapter();
