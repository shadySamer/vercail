import { AffiliateNetworkAdapter, PostbackContext } from './AffiliateNetworkAdapter';
import { CanonicalEventType, NormalizedNetworkResult } from '../../types';
import { decryptSecret, verifyDigistore24Signature } from '../../security/crypto';
import { extractCleanTtclid } from '../../security/clickIdHelper';

export class Digistore24Adapter implements AffiliateNetworkAdapter {
  public network = 'digistore24' as const;

  public async verify(context: PostbackContext): Promise<{ isValid: boolean; error?: string }> {
    const secret = context.networkAccount.webhookSecretEncrypted
      ? decryptSecret(context.networkAccount.webhookSecretEncrypted)
      : undefined;

    if (secret) {
      const params = { ...context.query, ...(typeof context.body === 'object' ? context.body : {}) };
      const signatureHeader = context.headers['x-digistore-signature'] || params.sha_sign;
      const isValid = verifyDigistore24Signature(secret, params, signatureHeader);
      if (!isValid && signatureHeader) {
        return { isValid: false, error: 'Invalid Digistore24 SHA-512 signature' };
      }
    }
    return { isValid: true };
  }

  public async normalize(context: PostbackContext): Promise<NormalizedNetworkResult> {
    const params = { ...context.query, ...(typeof context.body === 'object' ? context.body : {}) };

    // Extract Click ID from cid / custom / subid
    const rawClickId = params.cid || params.custom || params.CID || params.subid || undefined;
    const clickId = extractCleanTtclid(rawClickId);

    // Transaction & Item IDs
    const transactionId = (params.order_id || params.orderid || params.transaction_id || `DS-${Date.now()}`).toString().trim();
    const orderItemId = params.order_item_id ? params.order_item_id.toString().trim() : undefined;

    // Commission payout (Digistore separates affiliate_amount from gross amount)
    const commissionRaw = params.affiliate_amount || params.affiliate_payout || params.amount || params.commission || '0';
    const commissionAmount = parseFloat(commissionRaw) || 0;

    // Gross basket / customer payment
    const grossRaw = params.gross_amount || params.billing_amount || params.amount || undefined;
    const grossAmount = grossRaw ? parseFloat(grossRaw) : undefined;

    // Currency
    const currency = (params.currency || params.billing_currency || 'USD').toUpperCase();

    // Event type mapping
    const rawEvent = (params.event || params.event_label || params.transaction_type || 'on_payment').toLowerCase();
    let eventType: CanonicalEventType = 'purchase';
    if (rawEvent === 'on_refund' || rawEvent.includes('refund')) {
      eventType = 'refund';
    } else if (rawEvent === 'on_chargeback' || rawEvent.includes('chargeback')) {
      eventType = 'chargeback';
    } else if (rawEvent.includes('rebill') || rawEvent.includes('recurring') || rawEvent === 'last_paid_day') {
      eventType = 'rebill';
    } else if (orderItemId && orderItemId !== transactionId && !rawEvent.includes('initial')) {
      eventType = 'upsell';
    }

    const productName = params.product_name || params.product_id ? `DS-${params.product_id}` : undefined;
    const campaignLabel = params.campaign_key || params.campaign || undefined;

    return {
      isVerified: true,
      transactionId,
      parentTransactionId: orderItemId ? transactionId : undefined,
      orderItemId,
      eventType,
      currency,
      commissionAmount,
      grossAmount,
      clickId,
      productName,
      campaignLabel,
      customerIp: params.ip || context.clientIp,
      customerUserAgent: params.user_agent || context.headers['user-agent'],
      customerEmail: params.buyer_email || params.email || undefined,
      rawDetails: params,
    };
  }

  public getSuccessResponse(_context: PostbackContext): { statusCode: number; body: string; contentType: string } {
    return {
      statusCode: 200,
      body: 'OK',
      contentType: 'text/plain',
    };
  }

  public buildDirectLink(baseUrl: string, clickIdMacro: string, metadata: Record<string, string> = {}): string {
    const url = new URL(baseUrl);
    url.searchParams.set('cid', clickIdMacro);
    if (metadata.campaign) url.searchParams.set('custom', metadata.campaign);
    return url.toString();
  }

  public buildPostbackTemplate(workspaceId: string, secretToken: string, host: string): string {
    const cleanHost = host.replace(/\/$/, '');
    return `${cleanHost}/api/v1/postbacks/digistore24/${workspaceId}/${secretToken}?cid={cid}&order_id={order_id}&order_item_id={order_item_id}&amount={affiliate_amount}&gross_amount={amount}&currency={currency}&event={event}`;
  }
}
