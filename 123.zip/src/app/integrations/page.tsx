'use client';

import { useState, useEffect } from 'react';
import { Pixel, NetworkAccount } from '@/lib/types';

interface SettingsData {
  adAccounts: Array<{ id: string; accountName: string; platform: string; status: string }>;
  pixels: Pixel[];
  networkAccounts: Array<NetworkAccount & {
    postbackUrl: string;
    clickIdMacroInstruction: string;
    clickIdExample: string;
  }>;
}

export default function IntegrationsPage() {
  const [data, setData] = useState<SettingsData | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [savingPixel, setSavingPixel] = useState(false);
  const [savingNetId, setSavingNetId] = useState<string | null>(null);

  // New/Edit Pixel Form State
  const [newPixelId, setNewPixelId] = useState('');
  const [newPixelName, setNewPixelName] = useState('');
  const [newAccessToken, setNewAccessToken] = useState('');
  const [newDefaultEvent, setNewDefaultEvent] = useState('CompletePayment');
  const [newTestCode, setNewTestCode] = useState('');
  const [pixelStatusMsg, setPixelStatusMsg] = useState<string | null>(null);

  const loadSettings = async () => {
    try {
      const res = await fetch('/api/v1/settings');
      const json = await res.json();
      setData(json);
    } catch (err) {
      console.error('Failed to load settings:', err);
    }
  };

  useEffect(() => {
    loadSettings();
  }, []);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  const handleSavePixel = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingPixel(true);
    setPixelStatusMsg(null);
    try {
      const res = await fetch('/api/v1/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'save_pixel',
          pixelId: newPixelId,
          name: newPixelName,
          accessToken: newAccessToken,
          eventName: newDefaultEvent,
          testEventCode: newTestCode,
        }),
      });
      const json = await res.json();
      if (json.success) {
        setPixelStatusMsg('✓ TikTok Pixel & Access Token saved successfully!');
        setNewPixelId('');
        setNewPixelName('');
        setNewAccessToken('');
        setNewTestCode('');
        await loadSettings();
      } else {
        setPixelStatusMsg(`Error: ${json.error}`);
      }
    } catch (err: any) {
      setPixelStatusMsg(`Error: ${err.message}`);
    } finally {
      setSavingPixel(false);
    }
  };

  const handleUpdateNetworkRoute = async (networkAccountId: string, targetPixelId: string, targetEventName: string) => {
    setSavingNetId(networkAccountId);
    try {
      await fetch('/api/v1/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'update_network',
          networkAccountId,
          targetPixelId,
          targetEventName,
        }),
      });
      await loadSettings();
    } catch (err) {
      console.error('Failed to update network route:', err);
    } finally {
      setSavingNetId(null);
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto w-full space-y-8">
      {/* Header */}
      <div className="border-b border-slate-800/80 pb-5">
        <h1 className="text-2xl font-bold text-white tracking-tight">Postback Hub & Network Setup</h1>
        <p className="text-sm text-slate-400 mt-1">
          Connect your TikTok Pixel, get Click ID instructions for your direct links, and copy your S2S Postback URLs
        </p>
      </div>

      {/* Section 1: TikTok Pixel & Events API Access Token */}
      <div className="bg-[#111827] border border-slate-800/80 rounded-xl p-6 shadow-sm space-y-5">
        <div>
          <h2 className="text-base font-bold text-white">1. TikTok Pixel & Events API Credentials</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Enter your TikTok Pixel ID and Long-lived Events API Access Token (No OAuth or full account connection needed)
          </p>
        </div>

        {/* Existing Pixels List */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {data?.pixels.map(pix => (
            <div key={pix.id} className="p-3.5 bg-[#0d1322] border border-slate-800 rounded-lg text-xs space-y-1.5 font-mono">
              <div className="flex items-center justify-between">
                <span className="font-bold text-white text-sm font-sans">{pix.name}</span>
                <span className="badge badge-success text-[10px]">ACTIVE PIXEL</span>
              </div>
              <div className="text-slate-400 flex justify-between">
                <span>Pixel ID:</span>
                <span className="text-white font-bold">{pix.pixelId}</span>
              </div>
              <div className="text-slate-400 flex justify-between">
                <span>Default Event:</span>
                <span className="text-blue-400 font-bold">{pix.eventName || 'CompletePayment'}</span>
              </div>
              {pix.testEventCode && (
                <div className="text-slate-400 flex justify-between">
                  <span>Test Event Code:</span>
                  <span className="text-amber-400">{pix.testEventCode}</span>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Add/Update Pixel Form */}
        <form onSubmit={handleSavePixel} className="pt-3 border-t border-slate-800 space-y-3 text-xs">
          <p className="font-semibold text-slate-300 uppercase tracking-wider">
            + Add or Update TikTok Pixel Destination
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div>
              <label className="block text-slate-400 mb-1">Pixel ID (Required)</label>
              <input
                type="text"
                required
                value={newPixelId}
                onChange={e => setNewPixelId(e.target.value)}
                placeholder="e.g. CP849201948201"
                className="w-full bg-[#0d1322] border border-slate-700 rounded-lg px-3 py-2 text-white font-mono focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Pixel Label Name</label>
              <input
                type="text"
                value={newPixelName}
                onChange={e => setNewPixelName(e.target.value)}
                placeholder="e.g. US Nutra Scale Pixel"
                className="w-full bg-[#0d1322] border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Events API Access Token</label>
              <input
                type="password"
                value={newAccessToken}
                onChange={e => setNewAccessToken(e.target.value)}
                placeholder="Paste Long-Lived Token"
                className="w-full bg-[#0d1322] border border-slate-700 rounded-lg px-3 py-2 text-white font-mono focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Default Event Name</label>
              <select
                value={newDefaultEvent}
                onChange={e => setNewDefaultEvent(e.target.value)}
                className="w-full bg-[#0d1322] border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500"
              >
                <option value="CompletePayment">CompletePayment (Purchase)</option>
                <option value="PlaceAnOrder">PlaceAnOrder</option>
                <option value="InitiateCheckout">InitiateCheckout</option>
                <option value="ViewContent">ViewContent</option>
              </select>
            </div>
          </div>

          <div className="flex items-center justify-between pt-2">
            <div className="w-1/2">
              <input
                type="text"
                value={newTestCode}
                onChange={e => setNewTestCode(e.target.value)}
                placeholder="Optional Sandbox Test Event Code (e.g. TEST84920)"
                className="w-full bg-[#0d1322] border border-slate-700 rounded-lg px-3 py-1.5 text-slate-300 font-mono text-[11px]"
              />
            </div>

            <button
              type="submit"
              disabled={savingPixel}
              className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-lg shadow-md shadow-blue-600/20 transition-all"
            >
              {savingPixel ? 'Saving...' : 'Save TikTok Pixel'}
            </button>
          </div>

          {pixelStatusMsg && (
            <p className={`text-xs font-semibold ${pixelStatusMsg.includes('✓') ? 'text-emerald-400' : 'text-rose-400'}`}>
              {pixelStatusMsg}
            </p>
          )}
        </form>
      </div>

      {/* Section 2: 4 Affiliate Networks Setup & Postback URLs */}
      <div className="space-y-4">
        <div>
          <h2 className="text-base font-bold text-white">2. Affiliate Networks Setup (Direct Linking Instructions)</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            For each network: append the Click ID parameter to your own affiliate link, and paste the Postback URL in the network dashboard
          </p>
        </div>

        <div className="grid grid-cols-1 gap-5">
          {data?.networkAccounts.map(net => (
            <div
              key={net.id}
              className="bg-[#111827] border border-slate-800/80 rounded-xl p-5 shadow-sm space-y-4"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-600/10 border border-blue-500/30 flex items-center justify-center font-bold text-blue-400 uppercase text-xs">
                    {net.network.substring(0, 3)}
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-sm">{net.accountName}</h3>
                    <p className="text-xs text-slate-400 uppercase">{net.network} Direct S2S Channel</p>
                  </div>
                </div>

                <span className="badge badge-success text-[10px] self-start sm:self-auto">
                  VERIFIED DIRECT S2S
                </span>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 text-xs">
                {/* Step A: Click ID instruction */}
                <div className="p-3.5 bg-[#0d1322] border border-slate-800 rounded-lg space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-amber-400">Step A: Add Click ID to your link</span>
                    <button
                      onClick={() => copyToClipboard(net.clickIdMacroInstruction, `macro-${net.id}`)}
                      className="text-[11px] text-blue-400 hover:text-blue-300 font-semibold"
                    >
                      {copiedId === `macro-${net.id}` ? '✓ Copied' : 'Copy Macro'}
                    </button>
                  </div>
                  <p className="text-slate-400">
                    Append this macro to your raw affiliate link before putting it in TikTok Ads:
                  </p>
                  <div className="bg-black/50 p-2 rounded border border-slate-900 font-mono text-emerald-400 text-[11px] select-all">
                    {net.clickIdMacroInstruction}
                  </div>
                  <p className="text-slate-500 text-[11px]">
                    Example: <span className="font-mono text-slate-400 break-all">{net.clickIdExample}</span>
                  </p>
                </div>

                {/* Step B: Postback URL */}
                <div className="p-3.5 bg-[#0d1322] border border-slate-800 rounded-lg space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-blue-400">Step B: Your Network Postback URL</span>
                    <button
                      onClick={() => copyToClipboard(net.postbackUrl, `post-${net.id}`)}
                      className="text-[11px] text-emerald-400 hover:text-emerald-300 font-semibold"
                    >
                      {copiedId === `post-${net.id}` ? '✓ Copied URL' : 'Copy Postback URL'}
                    </button>
                  </div>
                  <p className="text-slate-400">
                    Paste this exact URL into your {net.network.toUpperCase()} Postback / Pixel Settings:
                  </p>
                  <div className="bg-black/50 p-2 rounded border border-slate-900 font-mono text-slate-300 text-[11px] break-all select-all">
                    {net.postbackUrl}
                  </div>
                </div>
              </div>

              {/* Step C: Target Pixel & Event Routing Selector */}
              <div className="pt-2 border-t border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-3">
                  <span className="font-semibold text-slate-300">Route Conversions to:</span>

                  <select
                    defaultValue={net.targetPixelId || data?.pixels[0]?.pixelId || ''}
                    id={`pixel-sel-${net.id}`}
                    className="bg-[#0d1322] border border-slate-700 rounded-lg px-3 py-1.5 text-white font-mono text-xs focus:outline-none focus:border-blue-500"
                  >
                    {data?.pixels.map(p => (
                      <option key={p.id} value={p.pixelId}>
                        {p.name} ({p.pixelId})
                      </option>
                    ))}
                  </select>

                  <select
                    defaultValue={net.targetEventName || 'CompletePayment'}
                    id={`event-sel-${net.id}`}
                    className="bg-[#0d1322] border border-slate-700 rounded-lg px-3 py-1.5 text-white text-xs focus:outline-none focus:border-blue-500"
                  >
                    <option value="CompletePayment">CompletePayment</option>
                    <option value="PlaceAnOrder">PlaceAnOrder</option>
                    <option value="InitiateCheckout">InitiateCheckout</option>
                  </select>
                </div>

                <button
                  onClick={() => {
                    const pixelSel = document.getElementById(`pixel-sel-${net.id}`) as HTMLSelectElement;
                    const eventSel = document.getElementById(`event-sel-${net.id}`) as HTMLSelectElement;
                    handleUpdateNetworkRoute(net.id, pixelSel.value, eventSel.value);
                  }}
                  disabled={savingNetId === net.id}
                  className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-white font-semibold rounded-lg border border-slate-700 text-xs transition-all"
                >
                  {savingNetId === net.id ? 'Saving...' : 'Save Network Route'}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
