'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

interface DashboardMetrics {
  adSpend: number;
  grossCommission: number;
  refundedCommission: number;
  netCommission: number;
  netProfit: number;
  roas: number;
  cpa: number;
  totalConversions: number;
  attributedConversions: number;
  unattributedConversions: number;
  acceptedDeliveries: number;
  attributionRate: number;
  deliveryRate: number;
  campaigns: Array<{
    campaignName: string;
    network: string;
    offerName: string;
    adSpend: number;
    conversionsCount: number;
    initialSalesCount: number;
    upsellsCount: number;
    refundsCount: number;
    grossCommission: number;
    refundedCommission: number;
    netCommission: number;
    netProfit: number;
    roas: number;
    cpa: number;
    status: 'profitable' | 'break_even' | 'unprofitable';
  }>;
}

export default function DashboardPage() {
  const [metrics, setMetrics] = useState<DashboardMetrics | null>(null);
  const [loading, setLoading] = useState(true);
  const [triggering, setTriggering] = useState(false);

  const fetchMetrics = async () => {
    try {
      const res = await fetch('/api/v1/analytics');
      const data = await res.json();
      setMetrics(data);
    } catch (err) {
      console.error('Failed to load metrics:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMetrics();
    const interval = setInterval(fetchMetrics, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleSimulateQuickConversion = async (network: string) => {
    setTriggering(true);
    try {
      await fetch('/api/v1/postbacks/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          network,
          clickId: `ttclid_${network}_${Date.now().toString(36)}`,
          orderId: `${network.substring(0, 2).toUpperCase()}-${Math.floor(Math.random() * 899999 + 100000)}`,
          amount: Math.floor(Math.random() * 80 + 90),
          eventType: 'purchase',
        }),
      });
      await fetchMetrics();
    } catch (err) {
      console.error('Simulate failed:', err);
    } finally {
      setTriggering(false);
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto w-full space-y-6">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800/80 pb-5">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Command Center</h1>
          <p className="text-sm text-slate-400 mt-1">
            Deterministic Server-to-Server Affiliate Conversion Hub for TikTok Ads
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => handleSimulateQuickConversion('maxweb')}
            disabled={triggering}
            className="px-3.5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-lg shadow-blue-600/20 transition-all flex items-center gap-1.5"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            {triggering ? 'Processing...' : '+ Test S2S Postback'}
          </button>

          <Link
            href="/integrations"
            className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-all"
          >
            Postbacks & Pixels Setup &rarr;
          </Link>
        </div>
      </div>

      {/* Pure Direct Linking Workflow Banner */}
      <div className="bg-[#111827] border border-blue-500/20 rounded-xl p-4 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3 text-xs">
          <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-sm shrink-0">
            ⚡
          </div>
          <div>
            <span className="font-bold text-white">Pure Direct Linking Architecture: </span>
            <span className="text-slate-300">
              Your traffic flows directly from TikTok Ad to Offer. Our platform receives S2S postbacks upon sale, extracts <code className="text-emerald-400 bg-black/40 px-1 py-0.5 rounded">ttclid</code>, and fires TikTok Events API without redirects.
            </span>
          </div>
        </div>

        <Link
          href="/integrations"
          className="text-xs font-bold text-blue-400 hover:text-blue-300 underline shrink-0"
        >
          View Setup Instructions
        </Link>
      </div>

      {/* Primary Financial Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Net Commission Card */}
        <div className="bg-[#111827] border border-slate-800/80 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium uppercase tracking-wider">
            <span>Net Commission</span>
            <span className="badge badge-success text-[10px]">Confirmed Payout</span>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-emerald-400">
              ${metrics ? metrics.netCommission.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '0.00'}
            </span>
          </div>
          <p className="text-[12px] text-slate-400 mt-2">
            Gross: ${metrics?.grossCommission.toFixed(2) || '0.00'} | Refunds: -${metrics?.refundedCommission.toFixed(2) || '0.00'}
          </p>
        </div>

        {/* Total Conversions Card */}
        <div className="bg-[#111827] border border-slate-800/80 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium uppercase tracking-wider">
            <span>Total Conversions</span>
            <span className="text-blue-400 text-xs font-bold font-mono">S2S Events</span>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-extrabold text-white">
              {metrics ? metrics.totalConversions : 0}
            </span>
          </div>
          <p className="text-[12px] text-slate-400 mt-2">
            {metrics?.attributedConversions || 0} Attributed &bull; {metrics?.unattributedConversions || 0} Unattributed
          </p>
        </div>

        {/* TikTok Delivery Rate Card */}
        <div className="bg-[#111827] border border-slate-800/80 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium uppercase tracking-wider">
            <span>TikTok Delivery Rate</span>
            <span className="badge badge-info text-[10px]">Events API v1.3</span>
          </div>
          <div className="mt-3 flex items-baseline gap-3">
            <span className="text-3xl font-extrabold text-blue-400">
              {metrics?.deliveryRate || 100}%
            </span>
            <span className="text-xs font-semibold text-slate-400">
              Accepted: {metrics?.acceptedDeliveries || 0}
            </span>
          </div>
          <p className="text-[12px] text-slate-400 mt-2">
            Deduplicated by unique Transaction & Item IDs
          </p>
        </div>

        {/* Attribution Quality Card */}
        <div className="bg-[#111827] border border-slate-800/80 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium uppercase tracking-wider">
            <span>ttclid Match Quality</span>
            <span className="badge badge-success text-[10px]">Deterministic</span>
          </div>
          <div className="mt-3 flex items-baseline gap-3">
            <span className="text-3xl font-extrabold text-emerald-400">
              {metrics?.attributionRate || 100}%
            </span>
          </div>
          <p className="text-[12px] text-slate-400 mt-2">
            0% AI guesswork &bull; 100% Click ID evidence
          </p>
        </div>
      </div>

      {/* Network Conversions Table */}
      <div className="bg-[#111827] border border-slate-800/80 rounded-xl overflow-hidden shadow-sm">
        <div className="p-4 border-b border-slate-800/80 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-white">Affiliate Conversions Stream</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Live S2S Postbacks received from MaxWeb, BuyGoods, Digistore24, and ClickBank
            </p>
          </div>

          <Link href="/conversions" className="text-xs text-blue-400 hover:text-blue-300 font-medium">
            Open Full Debugger &rarr;
          </Link>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#0d1322] text-slate-400 font-semibold uppercase tracking-wider border-b border-slate-800/80">
              <tr>
                <th className="py-3 px-4">Network</th>
                <th className="py-3 px-4">Campaign / Label</th>
                <th className="py-3 px-4">Offer / Product</th>
                <th className="py-3 px-4 text-center">Conversions</th>
                <th className="py-3 px-4 text-center">Sales / Upsells</th>
                <th className="py-3 px-4 text-right">Net Commission</th>
                <th className="py-3 px-4 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {metrics && metrics.campaigns.length > 0 ? (
                metrics.campaigns.map((camp, idx) => (
                  <tr key={idx} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-3.5 px-4">
                      <span className="badge badge-info text-[11px] uppercase">
                        {camp.network}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 font-mono font-medium text-white">
                      {camp.campaignName}
                    </td>
                    <td className="py-3.5 px-4 text-slate-200">
                      {camp.offerName}
                    </td>
                    <td className="py-3.5 px-4 text-center font-bold text-white font-mono">
                      {camp.conversionsCount}
                    </td>
                    <td className="py-3.5 px-4 text-center text-slate-400 font-mono">
                      {camp.initialSalesCount} / <span className="text-emerald-400 font-bold">{camp.upsellsCount}</span>
                      {camp.refundsCount > 0 && <span className="text-rose-400 ml-1">(-{camp.refundsCount})</span>}
                    </td>
                    <td className="py-3.5 px-4 text-right font-bold text-emerald-400 font-mono">
                      ${camp.netCommission.toFixed(2)}
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <span className="badge badge-success">
                        ATTRIBUTED
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={7} className="text-center py-8 text-slate-400">
                    No conversion traffic recorded yet. Test an S2S postback or configure your network postback URL.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
