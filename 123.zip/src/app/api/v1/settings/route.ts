import { NextRequest, NextResponse } from 'next/server';
import { v4 as uuidv4 } from 'uuid';
import { db } from '@/lib/db/store';
import { postbackGenerator } from '@/lib/engine/PostbackGenerator';
import { encryptSecret } from '@/lib/security/crypto';
import { DEFAULT_WORKSPACE_ID } from '@/lib/db/seed';

export async function GET(request: NextRequest) {
  const url = new URL(request.url);
  const workspaceId = url.searchParams.get('workspaceId') || DEFAULT_WORKSPACE_ID;
  const origin = url.origin;

  const workspaces = db.getWorkspaces();
  const adAccounts = db.getAdAccounts(workspaceId);
  const pixels = db.getPixels(workspaceId);
  const networkAccounts = db.getNetworkAccounts(workspaceId);
  const offers = db.getOffers(workspaceId);

  // Enrich network accounts with generated postback URLs and parameter tips
  const enrichedNetworks = networkAccounts.map(n => {
    const postbackUrl = postbackGenerator.generate(n.network, workspaceId, n.secretToken, origin);

    let clickIdMacroInstruction = '&subid5=__CLICKID__';
    let clickIdExample = 'https://maxweb.com/aff/1234/5678?subid5=__CLICKID__';
    if (n.network === 'buygoods') {
      clickIdMacroInstruction = '&subid=__CLICKID__';
      clickIdExample = 'https://www.buygoods.com/affiliate/redirect.html?aff_id=8831&prod_id=7102&subid=__CLICKID__';
    } else if (n.network === 'digistore24') {
      clickIdMacroInstruction = '&cid=__CLICKID__';
      clickIdExample = 'https://www.digistore24.com/redir/48190/AFFILIATE/CAMPAIGN?cid=__CLICKID__';
    } else if (n.network === 'clickbank') {
      clickIdMacroInstruction = '&extclid=__CLICKID__';
      clickIdExample = 'https://hop.clickbank.net/?affiliate=AFFID&vendor=VENDORID&extclid=__CLICKID__&traffic_source=tiktok';
    }

    return {
      ...n,
      postbackUrl,
      clickIdMacroInstruction,
      clickIdExample,
    };
  });

  return NextResponse.json({
    workspace: workspaces.find(w => w.id === workspaceId) || workspaces[0],
    adAccounts,
    pixels,
    networkAccounts: enrichedNetworks,
    offers,
  });
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const action = body.action;
    const workspaceId = body.workspaceId || DEFAULT_WORKSPACE_ID;

    // Action 1: Save / Update TikTok Pixel
    if (action === 'save_pixel') {
      const pixelId = body.pixelId?.trim();
      const pixelName = body.name?.trim() || `TikTok Pixel (${pixelId})`;
      const accessToken = body.accessToken?.trim();
      const eventName = body.eventName?.trim() || 'CompletePayment';
      const testEventCode = body.testEventCode?.trim() || undefined;

      if (!pixelId) {
        return NextResponse.json({ error: 'Pixel ID is required' }, { status: 400 });
      }

      const existingPixels = db.getPixels(workspaceId);
      let targetPixel = existingPixels.find(p => p.pixelId === pixelId);

      if (targetPixel) {
        targetPixel.name = pixelName;
        targetPixel.eventName = eventName;
        targetPixel.testEventCode = testEventCode;
        if (accessToken) {
          targetPixel.accessTokenEncrypted = encryptSecret(accessToken);
        }
        db.savePixel(targetPixel);
      } else {
        targetPixel = {
          id: uuidv4(),
          workspaceId,
          pixelId,
          name: pixelName,
          accessTokenEncrypted: accessToken ? encryptSecret(accessToken) : encryptSecret('mock_live_token'),
          eventName,
          testEventCode,
          isDefault: existingPixels.length === 0,
          status: 'active',
          createdAt: new Date().toISOString(),
        };
        db.savePixel(targetPixel);
      }

      return NextResponse.json({ success: true, pixel: targetPixel });
    }

    // Action 2: Update Network Account target pixel & event
    if (action === 'update_network') {
      const networkAccountId = body.networkAccountId;
      const targetPixelId = body.targetPixelId;
      const targetEventName = body.targetEventName;
      const webhookSecret = body.webhookSecret;

      const networkAccount = db.getNetworkAccounts(workspaceId).find(n => n.id === networkAccountId);
      if (!networkAccount) {
        return NextResponse.json({ error: 'Network account not found' }, { status: 404 });
      }

      if (targetPixelId !== undefined) networkAccount.targetPixelId = targetPixelId;
      if (targetEventName !== undefined) networkAccount.targetEventName = targetEventName;
      if (webhookSecret !== undefined) {
        networkAccount.webhookSecretEncrypted = encryptSecret(webhookSecret);
      }

      db.saveNetworkAccount(networkAccount);
      return NextResponse.json({ success: true, networkAccount });
    }

    return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
