import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db/store';
import { NetworkType, CanonicalEventType } from '@/lib/types';
import { DEFAULT_WORKSPACE_ID } from '@/lib/db/seed';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const network = (body.network || 'maxweb') as NetworkType;
    const workspaceId = body.workspaceId || DEFAULT_WORKSPACE_ID;
    const clickId = body.clickId || `E.C.P.demo_${Date.now()}`;
    const orderId = body.orderId || `ORD-${Date.now()}`;
    const amount = Number(body.amount || 135.0);
    const eventType = (body.eventType || 'purchase') as CanonicalEventType;
    const isDuplicate = !!body.isDuplicate;

    const networkAccounts = db.getNetworkAccounts(workspaceId);
    const networkAccount = networkAccounts.find(n => n.network === network) || networkAccounts[0];

    if (!networkAccount) {
      return NextResponse.json({ error: `No network account found for ${network}` }, { status: 404 });
    }

    // Construct realistic mock request according to verified network parameters
    let endpointUrl = `/api/v1/postbacks/${network}/${workspaceId}/${networkAccount.secretToken}`;
    let requestMethod = 'GET';
    let queryParams: Record<string, string> = {};
    let postBody: any = undefined;

    if (network === 'maxweb') {
      queryParams = {
        subid: clickId,
        subid2: body.campaign || 'TT-US-NUTR-01',
        subid3: body.adgroup || 'AG-BROAD',
        subid4: body.ad || 'AD-01',
        subid5: body.creative || 'CR-VIDEO',
        order_id: orderId,
        amount: amount.toString(),
        product: body.productName || 'ProDentim Dental Health',
        currency: 'USD',
        event: eventType === 'refund' ? 'refund' : eventType === 'upsell' ? 'upsell' : 'sale',
      };
    } else if (network === 'buygoods') {
      queryParams = {
        subid: clickId,
        subid2: body.campaign || 'TT-US-VSL-SCALE',
        subid3: body.adgroup || 'AG-HEALTH',
        order_id: orderId,
        amount: amount.toString(),
        product: body.productName || 'NeuroDr Brain Clarity',
      };
    } else if (network === 'digistore24') {
      queryParams = {
        cid: clickId,
        order_id: orderId,
        order_item_id: eventType === 'upsell' ? `${orderId}-UP1` : orderId,
        amount: amount.toString(),
        gross_amount: (amount * 1.4).toString(),
        currency: 'USD',
        event: eventType === 'refund' ? 'on_refund' : eventType === 'chargeback' ? 'on_chargeback' : 'on_payment',
        campaign: body.campaign || 'TT-GLOBAL-DIGI',
      };
    } else if (network === 'clickbank') {
      requestMethod = 'POST';
      postBody = {
        receipt: orderId,
        transactionType: eventType === 'refund' ? 'RFND' : eventType === 'rebill' ? 'BILL' : 'SALE',
        totalAccountAmount: amount.toString(),
        totalOrderAmount: (amount * 1.35).toString(),
        currency: 'USD',
        extclid: clickId,
        campaign: body.campaign || 'TT-CB-ALPHA',
        adgroup: 'AG-ENERGY',
        lineItems: [
          {
            itemNo: '1',
            productTitle: body.productName || 'Alpha Tonic Male Energy',
          },
        ],
      };
    }

    // Execute internal postback route directly
    const origin = new URL(request.url).origin;
    const fullUrl = new URL(endpointUrl, origin);
    Object.entries(queryParams).forEach(([k, v]) => fullUrl.searchParams.set(k, v));

    const response = await fetch(fullUrl.toString(), {
      method: requestMethod,
      headers: {
        'Content-Type': 'application/json',
        'x-simulated-postback': 'true',
      },
      body: postBody ? JSON.stringify(postBody) : undefined,
    });

    const responseText = await response.text();

    return NextResponse.json({
      success: response.ok,
      httpStatus: response.status,
      networkResponse: responseText,
      simulatedDetails: {
        network,
        orderId,
        clickId,
        amount,
        eventType,
        url: fullUrl.toString(),
      },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
