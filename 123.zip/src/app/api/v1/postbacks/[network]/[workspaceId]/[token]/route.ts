import { NextRequest, NextResponse } from 'next/server';
import { v4 as uuidv4 } from 'uuid';
import { db } from '@/lib/db/store';
import { networkRegistry } from '@/lib/adapters/network/NetworkRegistry';
import { idempotencyEngine } from '@/lib/engine/IdempotencyEngine';
import { attributionEngine } from '@/lib/engine/AttributionEngine';
import { outboxWorker } from '@/lib/engine/OutboxWorker';
import { NetworkType, RawInboundEvent, CanonicalConversion, OutboxTask } from '@/lib/types';

interface RouteParams {
  params: {
    network: string;
    workspaceId: string;
    token: string;
  };
}

export async function GET(request: NextRequest, { params }: RouteParams) {
  return handlePostback(request, params, {});
}

export async function POST(request: NextRequest, { params }: RouteParams) {
  let body: any = {};
  const contentType = request.headers.get('content-type') || '';
  try {
    if (contentType.includes('application/json')) {
      body = await request.json();
    } else if (contentType.includes('application/x-www-form-urlencoded')) {
      const formData = await request.formData();
      const obj: Record<string, any> = {};
      formData.forEach((value, key) => {
        obj[key] = value;
      });
      body = obj;
    } else {
      const text = await request.text();
      try {
        body = JSON.parse(text);
      } catch {
        body = { rawText: text };
      }
    }
  } catch (err) {
    body = { parseError: 'Failed to read body stream' };
  }

  return handlePostback(request, params, body);
}

async function handlePostback(request: NextRequest, params: RouteParams['params'], body: any) {
  const network = params.network.toLowerCase() as NetworkType;
  const workspaceId = params.workspaceId;
  const token = params.token;

  const url = new URL(request.url);
  const queryParams: Record<string, string> = {};
  url.searchParams.forEach((val, key) => {
    queryParams[key] = val;
  });

  const headers: Record<string, string> = {};
  request.headers.forEach((val, key) => {
    headers[key] = val;
  });

  const clientIp = headers['x-forwarded-for']?.split(',')[0].trim() || '127.0.0.1';

  // 1. Immutable Raw Inbound Ledger Record
  const rawEventId = uuidv4();
  const rawInboundEvent: RawInboundEvent = {
    id: rawEventId,
    workspaceId,
    network,
    headers,
    queryParams,
    body,
    rawPayload: JSON.stringify({ query: queryParams, body }),
    clientIp,
    verificationStatus: 'unverified',
    processingStatus: 'processed',
    receivedAt: new Date().toISOString(),
  };

  const adapter = networkRegistry.getAdapter(network);
  if (!adapter) {
    rawInboundEvent.verificationStatus = 'invalid_token';
    rawInboundEvent.processingStatus = 'failed';
    rawInboundEvent.errorMessage = `Unsupported affiliate network: ${network}`;
    db.logRawInboundEvent(rawInboundEvent);
    return new NextResponse('Unsupported Network', { status: 400 });
  }

  // 2. Resolve Network Account & Token Authenticity
  const networkAccount = db.getNetworkAccountByToken(network, workspaceId, token);
  if (!networkAccount) {
    rawInboundEvent.verificationStatus = 'invalid_token';
    rawInboundEvent.processingStatus = 'failed';
    rawInboundEvent.errorMessage = `Invalid security token or unknown account for network: ${network}`;
    db.logRawInboundEvent(rawInboundEvent);
    return new NextResponse('Unauthorized: Invalid Ingestion Token', { status: 401 });
  }

  rawInboundEvent.networkAccountId = networkAccount.id;

  // 3. Signature & Payload Verification
  const postbackContext = {
    network,
    workspaceId,
    networkAccount,
    headers,
    query: queryParams,
    body,
    clientIp,
  };

  const verification = await adapter.verify(postbackContext);
  if (!verification.isValid) {
    rawInboundEvent.verificationStatus = 'failed_signature';
    rawInboundEvent.processingStatus = 'failed';
    rawInboundEvent.errorMessage = verification.error || 'Cryptographic signature verification failed';
    db.logRawInboundEvent(rawInboundEvent);
    return new NextResponse(`Verification Failed: ${verification.error}`, { status: 403 });
  }

  rawInboundEvent.verificationStatus = 'verified';

  // 4. Normalize to Canonical Data Model
  const normalized = await adapter.normalize(postbackContext);

  // 5. Idempotency & Deduplication Engine Check
  const idempotencyKey = idempotencyEngine.generateKey(
    network,
    networkAccount.id,
    normalized.transactionId,
    normalized.eventType,
    normalized.orderItemId
  );

  const idempotencyCheck = idempotencyEngine.check(idempotencyKey);
  if (idempotencyCheck.isDuplicate) {
    rawInboundEvent.processingStatus = 'duplicate';
    rawInboundEvent.errorMessage = `Duplicate transaction suppressed: ${normalized.transactionId}`;
    db.logRawInboundEvent(rawInboundEvent);

    // Update Health duplicate count
    const healthList = db.getIntegrationHealth(workspaceId);
    const health = healthList.find(h => h.networkAccountId === networkAccount.id);
    if (health) {
      health.duplicateCount += 1;
      health.updatedAt = new Date().toISOString();
      db.updateIntegrationHealth(health);
    }

    const successResp = adapter.getSuccessResponse(postbackContext);
    return new NextResponse(successResp.body, {
      status: successResp.statusCode,
      headers: { 'Content-Type': successResp.contentType },
    });
  }

  // 6. Deterministic Attribution
  const attribution = attributionEngine.attribute(normalized, networkAccount, workspaceId);

  // 7. Persist Canonical Conversion
  const conversionId = uuidv4();
  const conversion: CanonicalConversion = {
    id: conversionId,
    workspaceId,
    rawEventId,
    network,
    networkAccountId: networkAccount.id,
    transactionId: normalized.transactionId,
    parentTransactionId: normalized.parentTransactionId,
    orderItemId: normalized.orderItemId,
    eventType: normalized.eventType,
    status: attribution.status === 'attributed' ? 'queued' : 'unattributed',
    currency: normalized.currency,
    commissionAmount: normalized.commissionAmount,
    grossAmount: normalized.grossAmount,
    clickId: normalized.clickId,
    trafficSource: 'tiktok',
    campaignId: attribution.campaignId,
    adgroupId: attribution.adgroupId,
    adId: attribution.adId,
    creativeId: attribution.creativeId,
    offerId: attribution.offerId,
    offerName: attribution.offerName,
    productName: normalized.productName,
    resolvedPixelId: attribution.resolvedPixel?.pixelId,
    resolvedAdAccountId: attribution.resolvedAdAccountId,
    customerIp: normalized.customerIp,
    customerUserAgent: normalized.customerUserAgent,
    idempotencyKey,
    receivedAt: rawInboundEvent.receivedAt,
    errorMessage: attribution.reason,
  };

  db.saveConversion(conversion);
  idempotencyEngine.record(idempotencyKey, conversionId, network);
  db.logRawInboundEvent(rawInboundEvent);

  // 8. Update Health Stats
  const healthList = db.getIntegrationHealth(workspaceId);
  let health = healthList.find(h => h.networkAccountId === networkAccount.id);
  if (health) {
    health.lastPostbackAt = rawInboundEvent.receivedAt;
    health.totalPostbacksReceived += 1;
    if (attribution.status === 'unattributed') {
      health.missingClickIdCount += 1;
    }
    const total = health.totalPostbacksReceived;
    const missing = health.missingClickIdCount;
    health.attributionRate = total > 0 ? Math.round(((total - missing) / total) * 100) : 100;
    health.updatedAt = new Date().toISOString();
    db.updateIntegrationHealth(health);
  }

  // 9. Enqueue Outbox Task if Attributed
  if (attribution.status === 'attributed' && attribution.resolvedPixel) {
    const outboxTask: OutboxTask = {
      id: uuidv4(),
      workspaceId,
      conversionId,
      adPlatform: 'tiktok',
      destinationPixelId: attribution.resolvedPixel.pixelId,
      payload: {
        event: 'CompletePayment',
        event_id: normalized.orderItemId || normalized.transactionId,
        click_id: normalized.clickId,
        value: normalized.commissionAmount,
        currency: normalized.currency,
      },
      status: 'pending',
      attempts: 0,
      maxAttempts: 5,
      nextRetryAt: new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    db.saveOutboxTask(outboxTask);

    // Asynchronously trigger outbox processing without blocking response
    setImmediate(() => {
      outboxWorker.processTask(outboxTask).catch(err => {
        console.error('Outbox worker dispatch error:', err);
      });
    });
  }

  // 10. Respond with Network-specific confirmation
  const successResp = adapter.getSuccessResponse(postbackContext);
  return new NextResponse(successResp.body, {
    status: successResp.statusCode,
    headers: { 'Content-Type': successResp.contentType },
  });
}
