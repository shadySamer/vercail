import { db } from '../src/lib/db/store';
import { seedInitialData, DEFAULT_WORKSPACE_ID } from '../src/lib/db/seed';
import { MaxWebAdapter } from '../src/lib/adapters/network/MaxWebAdapter';
import { BuyGoodsAdapter } from '../src/lib/adapters/network/BuyGoodsAdapter';
import { Digistore24Adapter } from '../src/lib/adapters/network/Digistore24Adapter';
import { ClickBankAdapter } from '../src/lib/adapters/network/ClickBankAdapter';
import { tikTokAdsAdapter } from '../src/lib/adapters/ad-platform/TikTokAdsAdapter';
import { idempotencyEngine } from '../src/lib/engine/IdempotencyEngine';
import { attributionEngine } from '../src/lib/engine/AttributionEngine';
import { extractCleanTtclid } from '../src/lib/security/clickIdHelper';
import { encryptSecret, decryptSecret, decryptClickBankINS, verifyDigistore24Signature, hashSha256 } from '../src/lib/security/crypto';
import crypto from 'crypto';

let passed = 0;
let failed = 0;

function assert(condition: boolean, testName: string, extra?: any) {
  if (condition) {
    console.log(`  \x1b[32m✓ PASS\x1b[0m: ${testName}`);
    passed++;
  } else {
    console.error(`  \x1b[31m✗ FAIL\x1b[0m: ${testName}`, extra ? extra : '');
    failed++;
  }
}

async function runTestSuite() {
  console.log('\n================================================================');
  console.log('🚀 RUNNING DIRECT LINKING S2S CONVERSION ATTRIBUTION TEST SUITE');
  console.log('================================================================\n');

  // Seed DB
  seedInitialData();

  // Test 1: Click ID Extraction & Wrapper Parsing
  console.log('[1. Resilient ttclid Extraction Tests]');
  assert(extractCleanTtclid('E.C.P.simple123') === 'E.C.P.simple123', 'Raw ttclid extracted');
  assert(extractCleanTtclid('ttclid(E.C.P.wrapped_paren)') === 'E.C.P.wrapped_paren', 'Parentheses wrapped ttclid extracted');
  assert(extractCleanTtclid('ttclid:E.C.P.colon_wrapped') === 'E.C.P.colon_wrapped', 'Colon wrapped ttclid extracted');
  assert(extractCleanTtclid('__CLICKID__') === undefined, 'Unreplaced macro correctly recognized as missing');
  assert(extractCleanTtclid('{SUBID}') === undefined, 'Unreplaced postback token recognized as missing');

  // Test 2: Cryptography & Security at Rest
  console.log('\n[2. Cryptography & Security Tests]');
  const rawSecret = 'tiktok_live_prod_token_abc_12345';
  const encrypted = encryptSecret(rawSecret);
  const decrypted = decryptSecret(encrypted);
  assert(encrypted !== rawSecret && encrypted.includes(':'), 'AES-256-GCM Encrypted payload format');
  assert(decrypted === rawSecret, 'AES-256-GCM Decryption matches original token');
  assert(hashSha256(' USER@EXAMPLE.COM ') === crypto.createHash('sha256').update('user@example.com').digest('hex'), 'SHA-256 Match Key normalization');

  // Test 3: Digistore24 SHA-512 Verification
  console.log('\n[3. Digistore24 Signature Verification]');
  const dsPassphrase = 'SECRET_PASSPHRASE_123';
  const dsParams = { amount: '120.00', cid: 'ttclid(E.C.P.ds_click_99)', order_id: 'DS-99128' };
  const sortedStr = 'amount=120.00cid=ttclid(E.C.P.ds_click_99)order_id=DS-99128';
  const validHash = crypto.createHash('sha512').update(dsPassphrase + sortedStr).digest('hex').toUpperCase();
  assert(verifyDigistore24Signature(dsPassphrase, dsParams, validHash), 'Digistore24 valid SHA-512 signature matches');
  assert(!verifyDigistore24Signature(dsPassphrase, dsParams, 'FORGED_SIGNATURE'), 'Digistore24 forged signature rejected');

  // Test 4: ClickBank INS AES-256-CBC Decryption
  console.log('\n[4. ClickBank INS Decryption]');
  const cbSecret = 'CBSECRETKEY';
  const cbKey = crypto.createHash('sha1').update(cbSecret).digest('hex').substring(0, 32);
  const cbIv = crypto.randomBytes(16);
  const samplePayload = JSON.stringify({ receipt: 'CB-TX-904', totalAccountAmount: '142.50', transactionType: 'SALE', extclid: 'ttclid(E.C.P.cb_click_88)' });
  const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(cbKey, 'utf8'), cbIv);
  let encryptedCB = cipher.update(samplePayload, 'utf8', 'base64');
  encryptedCB += cipher.final('base64');
  const decryptedCB = decryptClickBankINS(cbSecret, cbIv.toString('base64'), encryptedCB);
  const parsedCB = JSON.parse(decryptedCB);
  assert(parsedCB.receipt === 'CB-TX-904' && parsedCB.extclid === 'ttclid(E.C.P.cb_click_88)', 'ClickBank INS decrypted accurately');

  // Test 5: MaxWeb Adapter Normalization with subid5
  console.log('\n[5. MaxWeb Adapter Normalization]');
  const maxweb = new MaxWebAdapter();
  const mwAccount = db.getNetworkAccounts(DEFAULT_WORKSPACE_ID).find(n => n.network === 'maxweb')!;
  const mwContext = {
    network: 'maxweb' as const,
    workspaceId: DEFAULT_WORKSPACE_ID,
    networkAccount: mwAccount,
    headers: { 'user-agent': 'TikTok/TestAgent' },
    query: {
      subid5: 'ttclid(E.C.P.ttclid_maxweb_subid5)',
      subid2: 'TT-US-NUTR-01',
      order_id: 'MW-ORD-8819',
      amount: '135.00',
      product: 'ProDentim',
      event: 'sale',
    },
    body: {},
    clientIp: '64.233.160.1',
  };
  const mwResult = await maxweb.normalize(mwContext);
  assert(mwResult.clickId === 'E.C.P.ttclid_maxweb_subid5', 'MaxWeb Click ID cleanly extracted from subid5');
  assert(mwResult.commissionAmount === 135.0, 'MaxWeb Commission parsed');
  assert(maxweb.getSuccessResponse(mwContext).body === 'OK', 'MaxWeb echoes OK response');

  // Test 6: BuyGoods Adapter Normalization
  console.log('\n[6. BuyGoods Adapter Normalization]');
  const buygoods = new BuyGoodsAdapter();
  const bgAccount = db.getNetworkAccounts(DEFAULT_WORKSPACE_ID).find(n => n.network === 'buygoods')!;
  const bgContext = {
    network: 'buygoods' as const,
    workspaceId: DEFAULT_WORKSPACE_ID,
    networkAccount: bgAccount,
    headers: {},
    query: {
      subid: 'ttclid:E.C.P.bg_colon_click',
      order_id: 'BG-9921',
      amount: '142.50',
      product: 'NeuroDr',
      event: 'purchase',
    },
    body: {},
    clientIp: '127.0.0.1',
  };
  const bgResult = await buygoods.normalize(bgContext);
  assert(bgResult.clickId === 'E.C.P.bg_colon_click', 'BuyGoods Click ID cleanly extracted');
  assert(bgResult.commissionAmount === 142.5, 'BuyGoods Commission parsed');

  // Test 7: Idempotency Engine & Burst Duplicate Prevention
  console.log('\n[7. Idempotency Engine & Burst Duplicate Prevention]');
  const txId = `BURST-TEST-${Date.now()}`;
  const idKey = idempotencyEngine.generateKey('maxweb', mwAccount.id, txId, 'purchase');
  assert(!idempotencyEngine.check(idKey).isDuplicate, 'First transaction is NOT marked duplicate');
  idempotencyEngine.record(idKey, 'conv-test-01', 'maxweb');
  assert(idempotencyEngine.check(idKey).isDuplicate, 'Second identical transaction IS marked duplicate');

  // Test 8: Deterministic Attribution Engine
  console.log('\n[8. Deterministic Attribution Engine]');
  const attrResult = attributionEngine.attribute(mwResult, mwAccount, DEFAULT_WORKSPACE_ID);
  assert(attrResult.status === 'attributed', 'Deterministic attribution matches with valid Click ID');
  assert(attrResult.resolvedPixel?.pixelId === 'CP849201948201', 'Resolved correct TikTok Pixel');

  // Test 9: TikTok Events API Adapter
  console.log('\n[9. TikTok Events API Adapter & Deduplication]');
  const testPixel = db.getPixels(DEFAULT_WORKSPACE_ID)[0];
  const testConversion = {
    id: 'conv-test-99',
    workspaceId: DEFAULT_WORKSPACE_ID,
    rawEventId: 'raw-99',
    network: 'maxweb' as const,
    networkAccountId: mwAccount.id,
    transactionId: 'MW-99128',
    eventType: 'purchase' as const,
    targetEventName: 'CompletePayment',
    status: 'queued' as const,
    currency: 'USD',
    commissionAmount: 135.0,
    clickId: 'E.C.P.ttclid_valid',
    trafficSource: 'tiktok',
    idempotencyKey: 'idemp-99',
    receivedAt: new Date().toISOString(),
  };
  const dispatchResult = await tikTokAdsAdapter.dispatchConversion(testConversion, testPixel, 'demo_token', { isSimulation: true });
  assert(dispatchResult.isSuccess, 'TikTok Events API dispatch accepted');
  assert(tikTokAdsAdapter.classifyError(429, {}) === 'RETRYABLE', 'Classify 429 as RETRYABLE');
  assert(tikTokAdsAdapter.classifyError(400, { code: 40001 }) === 'PERMANENT', 'Classify token error as PERMANENT');

  // Test 10: Multi-Tenant Workspace Isolation
  console.log('\n[10. Tenant Workspace Isolation]');
  const otherWsAccounts = db.getNetworkAccounts('non-existent-workspace');
  assert(otherWsAccounts.length === 0, 'Cross-workspace data access isolated');

  console.log('\n================================================================');
  console.log(`🏁 TEST SUITE FINISHED: ${passed} PASSED, ${failed} FAILED`);
  console.log('================================================================\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runTestSuite().catch(err => {
  console.error('Test Suite Error:', err);
  process.exit(1);
});
