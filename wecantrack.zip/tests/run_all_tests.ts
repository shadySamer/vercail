import { db } from '../src/lib/db/store';
import { seedInitialData, DEFAULT_WORKSPACE_ID } from '../src/lib/db/seed';
import { MaxWebAdapter } from '../src/lib/adapters/network/MaxWebAdapter';
import { BuyGoodsAdapter } from '../src/lib/adapters/network/BuyGoodsAdapter';
import { Digistore24Adapter } from '../src/lib/adapters/network/Digistore24Adapter';
import { ClickBankAdapter } from '../src/lib/adapters/network/ClickBankAdapter';
import { tikTokAdsAdapter } from '../src/lib/adapters/ad-platform/TikTokAdsAdapter';
import { idempotencyEngine } from '../src/lib/engine/IdempotencyEngine';
import { attributionEngine } from '../src/lib/engine/AttributionEngine';
import { extractCleanTtclid } from '../src/lib/security/clickIdHelper';
import { encryptSecret, decryptSecret, decryptClickBankINS, verifyDigistore24Signature, hashSha256 } from '../src/lib/security/crypto';
import crypto from 'crypto';

let passed = 0;
let failed = 0;

function assert(condition: boolean, testName: string, extra?: any) {
  if (condition) {
    console.log(`  \x1b[32m✓ PASS\x1b[0m: ${testName}`);
    passed++;
  } else {
    console.error(`  \x1b[31m✗ FAIL\x1b[0m: ${testName}`, extra ? extra : '');
    failed++;
  }
}

async function runTestSuite() {
  console.log('\n================================================================');
  console.log('🚀 RUNNING DIRECT LINKING S2S CONVERSION ATTRIBUTION TEST SUITE');
  console.log('================================================================\n');

  // Seed DB
  seedInitialData();

  // Test 1: Click ID Extraction & Wrapper Parsing
  console.log('[1. Resilient ttclid Extraction Tests]');
  assert(extractCleanTtclid('E.C.P.simple123') === 'E.C.P.simple123', 'Raw ttclid extracted');
  assert(extractCleanTtclid('ttclid(E.C.P.wrapped_paren)') === 'E.C.P.wrapped_paren', 'Parentheses wrapped ttclid(E.C.P...) extracted');
  assert(extractCleanTtclid('ttclid:E.C.P.colon_wrapped') === 'E.C.P.colon_wrapped', 'Colon wrapped ttclid:E.C.P... extracted');
  assert(extractCleanTtclid('__CLICKID__') === undefined, 'Unreplaced macro recognized as missing');
  assert(extractCleanTtclid('{SUBID}') === undefined, 'Unreplaced postback token recognized as missing');

  // Test 2: Mandatory Transaction ID validation (NO FAKE IDs)
  console.log('\n[2. Strict Mandatory Transaction ID Tests (No Fake Fallback)]');
  const maxweb = new MaxWebAdapter();
  const mwAccount = db.getNetworkAccounts(DEFAULT_WORKSPACE_ID).find(n => n.network === 'maxweb')!;
  const invalidMwContext = {
    network: 'maxweb' as const,
    workspaceId: DEFAULT_WORKSPACE_ID,
    networkAccount: mwAccount,
    headers: {},
    query: { subid5: 'ttclid(E.C.P.123)', amount: '100' }, // NO order_id!
    body: {},
    clientIp: '127.0.0.1',
  };
  const invalidResult = await maxweb.normalize(invalidMwContext);
  assert(invalidResult.isVerified === false && invalidResult.transactionId === '', 'MaxWeb missing Order ID rejected without fake fallback');

  const digistore = new Digistore24Adapter();
  const dsAccount = db.getNetworkAccounts(DEFAULT_WORKSPACE_ID).find(n => n.network === 'digistore24')!;
  const invalidDsContext = {
    network: 'digistore24' as const,
    workspaceId: DEFAULT_WORKSPACE_ID,
    networkAccount: dsAccount,
    headers: {},
    query: { cid: 'ttclid(E.C.P.456)', amount_affiliate: '50' }, // NO transaction_id!
    body: {},
    clientIp: '127.0.0.1',
  };
  const invalidDsResult = await digistore.normalize(invalidDsContext);
  assert(invalidDsResult.isVerified === false && invalidDsResult.transactionId === '', 'Digistore24 missing Transaction ID rejected without fake fallback');

  // Test 3: Digistore24 Official S2S Placeholders Normalization
  console.log('\n[3. Digistore24 Official Affiliate S2S Placeholders]');
  const dsValidContext = {
    network: 'digistore24' as const,
    workspaceId: DEFAULT_WORKSPACE_ID,
    networkAccount: dsAccount,
    headers: {},
    query: {
      cid: 'ttclid(E.C.P.ds_real_click_99)',
      transaction_id: 'DS-TX-882109',
      order_type: 'initial_sale',
      amount_affiliate: '147.50',
      currency: 'USD',
      transaction_type: 'payment',
      product_id: '48190',
    },
    body: {},
    clientIp: '127.0.0.1',
  };
  const dsValidResult = await digistore.normalize(dsValidContext);
  assert(dsValidResult.isVerified === true, 'Digistore24 valid S2S parsed');
  assert(dsValidResult.transactionId === 'DS-TX-882109', 'Digistore24 exact transaction ID parsed');
  assert(dsValidResult.clickId === 'E.C.P.ds_real_click_99', 'Digistore24 ttclid stripped and extracted');
  assert(dsValidResult.commissionAmount === 147.50, 'Digistore24 amount_affiliate mapped as commission');

  // Test 4: MaxWeb subid5 ttclid Normalization
  console.log('\n[4. MaxWeb subid5 & ORDERID Normalization]');
  const mwValidContext = {
    network: 'maxweb' as const,
    workspaceId: DEFAULT_WORKSPACE_ID,
    networkAccount: mwAccount,
    headers: {},
    query: {
      subid5: 'ttclid(E.C.P.mw_click_77)',
      order_id: 'MW-99120',
      amount: '135.00',
      product: 'ProDentim',
      event: 'sale',
    },
    body: {},
    clientIp: '127.0.0.1',
  };
  const mwValidResult = await maxweb.normalize(mwValidContext);
  assert(mwValidResult.transactionId === 'MW-99120', 'MaxWeb exact Order ID parsed');
  assert(mwValidResult.clickId === 'E.C.P.mw_click_77', 'MaxWeb ttclid stripped from subid5');
  assert(mwValidResult.commissionAmount === 135.0, 'MaxWeb commission amount parsed');

  // Test 5: ClickBank extclid & receipt Normalization
  console.log('\n[5. ClickBank extclid & receipt Normalization]');
  const clickbank = new ClickBankAdapter();
  const cbAccount = db.getNetworkAccounts(DEFAULT_WORKSPACE_ID).find(n => n.network === 'clickbank')!;
  const cbValidContext = {
    network: 'clickbank' as const,
    workspaceId: DEFAULT_WORKSPACE_ID,
    networkAccount: cbAccount,
    headers: {},
    query: {
      extclid: 'ttclid(E.C.P.cb_extclid_33)',
      receipt: 'CB-REC-55410',
      amount: '154.00',
      transactionType: 'SALE',
      currency: 'USD',
    },
    body: {},
    clientIp: '127.0.0.1',
  };
  const cbValidResult = await clickbank.normalize(cbValidContext);
  assert(cbValidResult.transactionId === 'CB-REC-55410', 'ClickBank receipt parsed');
  assert(cbValidResult.clickId === 'E.C.P.cb_extclid_33', 'ClickBank extclid stripped and extracted');
  assert(cbValidResult.commissionAmount === 154.0, 'ClickBank commission parsed');

  // Test 6: Idempotency Burst & Duplicate Prevention
  console.log('\n[6. Idempotency Burst & Duplicate Prevention]');
  const uniqueOrder = `TX-UNIQUE-${Date.now()}`;
  const idKey = idempotencyEngine.generateKey('maxweb', mwAccount.id, uniqueOrder, 'purchase');
  assert(!idempotencyEngine.check(idKey).isDuplicate, 'New transaction is NOT duplicate');
  idempotencyEngine.record(idKey, 'conv-test-idemp', 'maxweb');
  assert(idempotencyEngine.check(idKey).isDuplicate, 'Duplicate transaction blocked');

  // Test 7: Direct Destination Attribution & Event Propagation
  console.log('\n[7. Direct Destination Attribution & Event Propagation]');
  const attr = attributionEngine.attribute(mwValidResult, mwAccount, DEFAULT_WORKSPACE_ID);
  assert(attr.status === 'attributed', 'Attribution successful with valid ttclid');
  assert(attr.targetEventName === 'CompletePayment', 'Exact target event name propagated');
  assert(attr.resolvedPixel?.pixelId === 'CP849201948201', 'Direct TikTok Destination resolved');

  // Test 8: TikTok Events API Adapter with Custom Event Name
  console.log('\n[8. TikTok Events API Adapter]');
  const testPixel = db.getPixels(DEFAULT_WORKSPACE_ID)[0];
  const testConversion = {
    id: 'conv-test-live',
    workspaceId: DEFAULT_WORKSPACE_ID,
    rawEventId: 'raw-live',
    network: 'maxweb' as const,
    networkAccountId: mwAccount.id,
    transactionId: 'MW-99120',
    eventType: 'purchase' as const,
    targetEventName: 'Purchase',
    status: 'queued' as const,
    currency: 'USD',
    commissionAmount: 135.0,
    clickId: 'E.C.P.mw_click_77',
    trafficSource: 'tiktok',
    idempotencyKey: 'idemp-live',
    receivedAt: new Date().toISOString(),
  };
  const dispatchResult = await tikTokAdsAdapter.dispatchConversion(testConversion, testPixel, 'demo_token', { isSimulation: true });
  assert(dispatchResult.isSuccess, 'TikTok Events API dispatch accepted');
  assert(dispatchResult.responseBody.data.event === 'Purchase', 'Exact custom event name received by TikTok API');

  // Test 9: Cryptography & Signature Check
  console.log('\n[9. Cryptography & Security]');
  const rawToken = 'secret_token_live_123';
  const enc = encryptSecret(rawToken);
  assert(decryptSecret(enc) === rawToken, 'AES-256-GCM token decryption verified');

  // Test 10: Missing Click ID marked Unattributed (No TikTok dispatch)
  console.log('\n[10. Missing Click ID Behavior]');
  const missingClickContext = {
    ...mwValidContext,
    query: { ...mwValidContext.query, subid5: '__CLICKID__' }, // Unreplaced macro!
  };
  const missingResult = await maxweb.normalize(missingClickContext);
  assert(missingResult.clickId === undefined, 'Unreplaced macro results in undefined clickId');
  const missingAttr = attributionEngine.attribute(missingResult, mwAccount, DEFAULT_WORKSPACE_ID);
  assert(missingAttr.status === 'unattributed', 'Missing Click ID marked as unattributed without fake attribution');

  console.log('\n================================================================');
  console.log(`🏁 TEST SUITE FINISHED: ${passed} PASSED, ${failed} FAILED`);
  console.log('================================================================\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runTestSuite().catch(err => {
  console.error('Test Suite Error:', err);
  process.exit(1);
});
